TripleA IPTV Player

This is a web player, not an Android APK.
Open the preview from the chat, or on a computer with Node.js 22:
  npm install
  npm run dev

Use the gear icon to enter an Xtream server or an M3U link.
The built-in list is public sample video only.
