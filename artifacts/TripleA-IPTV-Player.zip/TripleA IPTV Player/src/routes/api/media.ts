import { createFileRoute } from "@tanstack/react-router";

const MAX_URL = 4000;
const MAX_HOPS = 3;

function blockedHost(hostname: string): boolean {
  const host = hostname.toLowerCase().replace(/^\[|\]$/g, "");
  if (
    host === "localhost" ||
    host.endsWith(".localhost") ||
    host.endsWith(".local") ||
    host === "0.0.0.0" ||
    host === "::" ||
    host === "::1" ||
    host === "metadata.google.internal"
  ) {
    return true;
  }
  const ipv4 = host.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (!ipv4) {
    if (host.includes(":")) {
      const head = host.split(":").find(Boolean) ?? "";
      if (head.startsWith("fc") || head.startsWith("fd") || head.startsWith("fe80")) return true;
    }
    return false;
  }
  const a = Number(ipv4[1]);
  const b = Number(ipv4[2]);
  if ([a, b, Number(ipv4[3]), Number(ipv4[4])].some((n) => n > 255)) return true;
  if (a === 10 || a === 127 || a === 0) return true;
  if (a === 169 && b === 254) return true;
  if (a === 172 && b >= 16 && b <= 31) return true;
  if (a === 192 && b === 168) return true;
  if (a === 100 && b >= 64 && b <= 127) return true;
  return false;
}

function publicUrl(raw: string): URL {
  if (raw.length > MAX_URL) throw new Error("URL is too long.");
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    throw new Error("That address is not a valid URL.");
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") {
    throw new Error("Only http and https addresses are allowed.");
  }
  if (blockedHost(url.hostname)) throw new Error("That address is not allowed.");
  return url;
}

async function pull(raw: string, hops = 0): Promise<{ response: Response; url: string }> {
  if (hops > MAX_HOPS) throw new Error("Too many redirects.");
  const url = publicUrl(raw);
  const response = await fetch(url, {
    redirect: "manual",
    headers: {
      accept: "*/*",
      "user-agent": "TripleA IPTV Player",
    },
  });
  if (response.status >= 300 && response.status < 400) {
    const location = response.headers.get("location");
    if (!location) return { response, url: url.toString() };
    return pull(new URL(location, url).toString(), hops + 1);
  }
  return { response, url: url.toString() };
}

function absoluteRef(ref: string, base: string): string {
  try {
    return new URL(ref, base).toString();
  } catch {
    return ref;
  }
}

function rewritePlaylist(text: string, base: string): string {
  return text
    .split(/\r?\n/)
    .map((line) => {
      const trimmed = line.trim();
      if (!trimmed) return line;
      if (trimmed.startsWith("#")) {
        return line.replace(/URI="([^"]+)"/gi, (_match, uri: string) => `URI="${absoluteRef(uri, base)}"`);
      }
      return absoluteRef(trimmed, base);
    })
    .join("\n");
}

function relay(upstream: Response, body: BodyInit | null): Response {
  const headers = new Headers();
  const type = upstream.headers.get("content-type");
  if (type) headers.set("content-type", type);
  headers.set("cache-control", "no-store");
  headers.set("access-control-allow-origin", "*");
  return new Response(body, { status: upstream.status, headers });
}

async function handle({ request }: { request: Request }): Promise<Response> {
  const raw = new URL(request.url).searchParams.get("url") ?? "";
  try {
    if (!raw) return new Response("Missing url.", { status: 400 });
    const { response, url } = await pull(raw);
    const type = response.headers.get("content-type") ?? "";
    const playlist = /mpegurl|m3u8/i.test(type) || /\.m3u8(\?|$)/i.test(url);
    if (!playlist || !response.body) return relay(response, response.body);
    const text = await response.text();
    return relay(response, rewritePlaylist(text, url));
  } catch (error) {
    const message = error instanceof Error ? error.message : "Could not fetch that address.";
    return new Response(message, { status: 400, headers: { "content-type": "text/plain" } });
  }
}

export const Route = createFileRoute("/api/media")({
  server: { handlers: { GET: handle } },
});
