import { useEffect, useMemo, useState } from "react";
import { Search, Settings, Star, Tv } from "lucide-react";
import {
  currentProgram,
  demoChannels,
  formatClock,
  formatTime,
  loadFavorites,
  loadM3u,
  loadSavedSource,
  loadXtream,
  nextProgram,
  saveFavorites,
  saveSource,
  type Channel,
  type Source,
} from "@/lib/iptv";
import { PreviewPlayer } from "@/components/triplea/player";

const WINDOW_MS = 3 * 60 * 60 * 1000;

function useNow() {
  const [now, setNow] = useState<number | null>(null);
  useEffect(() => {
    const tick = () => setNow(Date.now());
    tick();
    const id = window.setInterval(tick, 30000);
    return () => window.clearInterval(id);
  }, []);
  return now;
}

export function TripleAApp() {
  const tick = useNow();
  const now = tick ?? 0;
  const [channels, setChannels] = useState<Channel[]>(() => demoChannels());
  const [source, setSource] = useState<Source>({ mode: "demo" });
  const [group, setGroup] = useState("All");
  const [query, setQuery] = useState("");
  const [selectedId, setSelectedId] = useState<string>("bunny");
  const [favorites, setFavorites] = useState<string[]>([]);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [booted, setBooted] = useState(false);

  useEffect(() => {
    const saved = loadSavedSource();
    const favs = loadFavorites();
    setFavorites(favs);
    setSource(saved);
    if (saved.mode === "demo") {
      setBooted(true);
      return;
    }
    const run = saved.mode === "m3u" ? loadM3u(saved.url) : loadXtream(saved.server, saved.username, saved.password);
    run
      .then((list) => {
        setChannels(list);
        setSelectedId(list[0]?.id ?? "");
      })
      .catch(() => {
        setSource({ mode: "demo" });
        setChannels(demoChannels());
      })
      .finally(() => setBooted(true));
  }, []);

  const groups = useMemo(() => {
    const names = new Set(channels.map((channel) => channel.group));
    return ["All", "Favorites", ...Array.from(names).sort((a, b) => a.localeCompare(b))];
  }, [channels]);

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return channels.filter((channel) => {
      if (group === "Favorites" && !favorites.includes(channel.id)) return false;
      if (group !== "All" && group !== "Favorites" && channel.group !== group) return false;
      if (!q) return true;
      return channel.name.toLowerCase().includes(q) || channel.group.toLowerCase().includes(q);
    });
  }, [channels, favorites, group, query]);

  const selected = visible.find((channel) => channel.id === selectedId) ?? visible[0] ?? channels[0];
  const onNow = selected ? currentProgram(selected, now) : undefined;
  const coming = selected ? nextProgram(selected, now) : undefined;
  const windowStart = now - (now % (30 * 60 * 1000));

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      const target = event.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) return;
      if (!visible.length) return;
      const index = Math.max(0, visible.findIndex((channel) => channel.id === selected?.id));
      if (event.key === "ArrowDown") {
        event.preventDefault();
        setSelectedId(visible[(index + 1) % visible.length].id);
      } else if (event.key === "ArrowUp") {
        event.preventDefault();
        setSelectedId(visible[(index - 1 + visible.length) % visible.length].id);
      } else if (event.key === "f" || event.key === "F") {
        if (selected) toggleFavorite(selected.id);
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  function toggleFavorite(id: string) {
    setFavorites((current) => {
      const next = current.includes(id) ? current.filter((item) => item !== id) : [...current, id];
      saveFavorites(next);
      return next;
    });
  }

  function applyChannels(list: Channel[], nextSource: Source) {
    setChannels(list);
    setSource(nextSource);
    saveSource(nextSource);
    setGroup("All");
    setQuery("");
    setSelectedId(list[0]?.id ?? "");
    setSettingsOpen(false);
  }

  return (
    <main className="flex h-dvh flex-col bg-bg text-fg">
      <header className="flex items-center gap-3 border-b border-line px-3 py-2 sm:px-4">
        <div className="flex items-center gap-2">
          <span className="flex size-9 items-center justify-center rounded-ui bg-accent text-fg">
            <Tv className="size-5" aria-hidden="true" />
          </span>
          <div className="leading-tight">
            <p className="text-sm font-semibold tracking-wide">TripleA</p>
            <p className="text-xs text-muted">IPTV Player</p>
          </div>
        </div>
        <p className="hidden flex-1 text-center text-sm text-muted sm:block">
          {tick ? formatClock(tick) : "Live guide"}
        </p>
        <label className="relative ml-auto hidden min-w-0 flex-1 sm:ml-0 sm:block sm:max-w-xs">
          <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted" />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search channels"
            className="h-11 w-full rounded-ui border border-line bg-panel pr-3 pl-9 text-sm text-fg outline-none placeholder:text-muted focus:border-accent"
            aria-label="Search channels"
          />
        </label>
        <button
          type="button"
          className="flex size-11 items-center justify-center rounded-ui border border-line bg-panel text-fg"
          onClick={() => setSettingsOpen(true)}
          aria-label="Sources and settings"
        >
          <Settings className="size-5" />
        </button>
      </header>

      <label className="relative mx-3 mt-3 sm:hidden">
        <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted" />
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search channels"
          className="h-11 w-full rounded-ui border border-line bg-panel pr-3 pl-9 text-sm outline-none placeholder:text-muted focus:border-accent"
          aria-label="Search channels"
        />
      </label>

      <div className="grid min-h-0 flex-1 grid-rows-[auto_auto_minmax(0,1fr)] lg:grid-cols-[11rem_18rem_minmax(0,1fr)] lg:grid-rows-none">
        <nav className="hidden flex-col gap-1 overflow-y-auto border-r border-line p-2 lg:flex" aria-label="Groups">
          {groups.map((name) => (
            <button
              key={name}
              type="button"
              onClick={() => setGroup(name)}
              className={
                name === group
                  ? "rounded-ui bg-accent px-3 py-2 text-left text-sm font-medium text-fg"
                  : "rounded-ui px-3 py-2 text-left text-sm text-muted hover:bg-panel hover:text-fg"
              }
            >
              {name}
              {name === "Favorites" ? ` (${favorites.length})` : ""}
            </button>
          ))}
        </nav>

        <div className="flex gap-2 overflow-x-auto px-3 py-2 lg:hidden">
          {groups.map((name) => (
            <button
              key={name}
              type="button"
              onClick={() => setGroup(name)}
              className={
                name === group
                  ? "shrink-0 rounded-full bg-accent px-3 py-2 text-sm text-fg"
                  : "shrink-0 rounded-full bg-panel px-3 py-2 text-sm text-muted"
              }
            >
              {name}
            </button>
          ))}
        </div>

        <section className="border-b border-line p-3 lg:hidden">
          {selected ? <PreviewPlayer url={selected.url} title={selected.name} /> : null}
          {onNow ? (
            <p className="mt-2 text-sm">
              <span className="font-medium">{onNow.title}</span>
              <span className="text-muted">
                {" "}
                · {formatTime(onNow.start)} – {formatTime(onNow.end)}
              </span>
            </p>
          ) : null}
        </section>

        <section className="min-h-0 overflow-y-auto border-line lg:border-r" aria-label="Channels">
          {visible.length === 0 ? (
            <p className="p-4 text-sm text-muted">
              {booted ? "No channels in this group." : "Loading channels…"}
            </p>
          ) : (
            <ul>
              {visible.map((channel) => {
                const active = channel.id === selected?.id;
                const program = currentProgram(channel, now);
                return (
                  <li key={channel.id} className={active ? "flex items-stretch bg-accent text-fg" : "flex items-stretch hover:bg-panel"}>
                    <button
                      type="button"
                      onClick={() => setSelectedId(channel.id)}
                      className="flex min-w-0 flex-1 items-center gap-3 px-3 py-2 text-left"
                    >
                      <span className="w-8 shrink-0 text-xs text-muted tabular-nums">{channel.number}</span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm font-medium">{channel.name}</span>
                        <span className="block truncate text-xs text-muted">{program?.title ?? "On air"}</span>
                      </span>
                    </button>
                    <button
                      type="button"
                      aria-pressed={favorites.includes(channel.id)}
                      aria-label={favorites.includes(channel.id) ? "Remove favorite" : "Add favorite"}
                      className="flex size-11 shrink-0 items-center justify-center"
                      onClick={() => toggleFavorite(channel.id)}
                    >
                      <Star className={favorites.includes(channel.id) ? "size-4 fill-fg text-fg" : "size-4 text-muted"} />
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </section>

        <section className="hidden min-h-0 grid-rows-[auto_minmax(0,1fr)] lg:grid">
          <div className="grid gap-3 border-b border-line p-3 xl:grid-cols-[minmax(0,20rem)_minmax(0,1fr)]">
            {selected ? <PreviewPlayer url={selected.url} title={selected.name} /> : null}
            <div className="min-w-0">
              <p className="text-xs tracking-wide text-accent uppercase">
                {source.mode === "demo" ? "Demo library" : source.mode === "m3u" ? "M3U playlist" : "Xtream"}
              </p>
              <h1 className="mt-1 truncate text-xl font-semibold">{onNow?.title ?? selected?.name ?? "TripleA"}</h1>
              <p className="mt-1 text-sm text-muted">
                {selected ? `${selected.number}  ${selected.name}` : "No channel"}
                {onNow ? `  ·  ${formatTime(onNow.start)} – ${formatTime(onNow.end)}` : ""}
              </p>
              <p className="mt-2 line-clamp-3 text-sm text-muted">{onNow?.description}</p>
              {coming ? (
                <p className="mt-3 text-sm">
                  <span className="text-muted">Next </span>
                  {coming.title}
                  <span className="text-muted"> · {formatTime(coming.start)}</span>
                </p>
              ) : null}
            </div>
          </div>
          <Guide channels={visible.slice(0, 18)} now={now} windowStart={windowStart} selectedId={selected?.id} onSelect={setSelectedId} />
        </section>
      </div>

      {settingsOpen ? (
        <SourceDialog
          source={source}
          onClose={() => setSettingsOpen(false)}
          onApply={applyChannels}
        />
      ) : null}
    </main>
  );
}

function Guide({
  channels,
  now,
  windowStart,
  selectedId,
  onSelect,
}: {
  channels: Channel[];
  now: number;
  windowStart: number;
  selectedId?: string;
  onSelect: (id: string) => void;
}) {
  const ticks = [0, 1, 2].map((hour) => windowStart + hour * 60 * 60 * 1000);
  const nowLeft = ((now - windowStart) / WINDOW_MS) * 100;
  return (
    <div className="min-h-0 overflow-auto">
      <div className="sticky top-0 z-10 grid grid-cols-[5rem_minmax(28rem,1fr)] border-b border-line bg-panel text-xs text-muted">
        <span className="px-3 py-2">Guide</span>
        <div className="relative h-8">
          {ticks.map((tick) => (
            <span
              key={tick}
              className="absolute top-2"
              style={{ left: `${((tick - windowStart) / WINDOW_MS) * 100}%` }}
            >
              {formatTime(tick)}
            </span>
          ))}
        </div>
      </div>
      <ul>
        {channels.map((channel) => (
          <li key={channel.id} className="grid grid-cols-[5rem_minmax(28rem,1fr)] border-b border-line">
            <button
              type="button"
              className={
                channel.id === selectedId
                  ? "truncate px-2 py-3 text-left text-xs font-medium text-fg"
                  : "truncate px-2 py-3 text-left text-xs text-muted"
              }
              onClick={() => onSelect(channel.id)}
            >
              {channel.name}
            </button>
            <div className="relative h-12">
              {channel.programs.map((program) => {
                if (program.end <= windowStart || program.start >= windowStart + WINDOW_MS) return null;
                const start = Math.max(program.start, windowStart);
                const end = Math.min(program.end, windowStart + WINDOW_MS);
                const left = ((start - windowStart) / WINDOW_MS) * 100;
                const width = ((end - start) / WINDOW_MS) * 100;
                const live = program.start <= now && now < program.end;
                return (
                  <button
                    key={program.id}
                    type="button"
                    onClick={() => onSelect(channel.id)}
                    className={
                      live
                        ? "absolute top-1 bottom-1 overflow-hidden rounded-md bg-accent px-2 text-left text-xs text-fg"
                        : "absolute top-1 bottom-1 overflow-hidden rounded-md bg-panel-2 px-2 text-left text-xs text-muted"
                    }
                    style={{ left: `${left}%`, width: `calc(${width}% - 4px)` }}
                    title={program.title}
                  >
                    <span className="block truncate leading-10">{program.title}</span>
                  </button>
                );
              })}
              {nowLeft >= 0 && nowLeft <= 100 && now > 0 ? (
                <span className="absolute top-0 bottom-0 w-px bg-live" style={{ left: `${nowLeft}%` }} aria-hidden="true" />
              ) : null}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

function SourceDialog({
  source,
  onClose,
  onApply,
}: {
  source: Source;
  onClose: () => void;
  onApply: (channels: Channel[], source: Source) => void;
}) {
  const [tab, setTab] = useState<Source["mode"]>(source.mode);
  const [m3u, setM3u] = useState(source.mode === "m3u" ? source.url : "");
  const [server, setServer] = useState(source.mode === "xtream" ? source.server : "");
  const [username, setUsername] = useState(source.mode === "xtream" ? source.username : "");
  const [password, setPassword] = useState(source.mode === "xtream" ? source.password : "");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function connect() {
    setError("");
    setBusy(true);
    try {
      if (tab === "demo") {
        onApply(demoChannels(), { mode: "demo" });
        return;
      }
      if (tab === "m3u") {
        const list = await loadM3u(m3u.trim());
        onApply(list, { mode: "m3u", url: m3u.trim() });
        return;
      }
      const list = await loadXtream(server.trim(), username.trim(), password);
      onApply(list, { mode: "xtream", server: server.trim(), username: username.trim(), password });
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Could not load that source.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="fixed inset-0 z-20 flex items-end justify-center bg-bg/80 p-3 sm:items-center" role="dialog" aria-modal="true" aria-labelledby="source-title">
      <div className="w-full max-w-lg rounded-ui border border-line bg-panel p-4 shadow-2xl">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h2 id="source-title" className="text-lg font-semibold">Sources</h2>
            <p className="mt-1 text-sm text-muted">
              TripleA plays your own Xtream login or M3U link. The demo library is public sample video, not a channel package.
            </p>
          </div>
          <button type="button" className="rounded-ui px-3 py-2 text-sm text-muted hover:text-fg" onClick={onClose}>
            Close
          </button>
        </div>
        <div className="mt-4 grid grid-cols-3 gap-2" role="tablist">
          {(
            [
              ["demo", "Demo"],
              ["xtream", "Xtream"],
              ["m3u", "M3U"],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              role="tab"
              aria-selected={tab === id}
              onClick={() => setTab(id)}
              className={
                tab === id
                  ? "h-11 rounded-ui bg-accent text-sm font-medium text-fg"
                  : "h-11 rounded-ui bg-panel-2 text-sm text-muted"
              }
            >
              {label}
            </button>
          ))}
        </div>
        {tab === "xtream" ? (
          <div className="mt-4 grid gap-3">
            <Field label="Server URL" value={server} onChange={setServer} placeholder="http://example.com:8080" />
            <Field label="Username" value={username} onChange={setUsername} placeholder="username" />
            <Field label="Password" value={password} onChange={setPassword} placeholder="password" secret />
          </div>
        ) : null}
        {tab === "m3u" ? (
          <div className="mt-4">
            <Field label="Playlist URL" value={m3u} onChange={setM3u} placeholder="https://example.com/list.m3u" />
          </div>
        ) : null}
        {tab === "demo" ? (
          <p className="mt-4 text-sm text-muted">
            Open movies and test patterns you can play immediately. Arrow keys change channel. F favorites the selected one.
          </p>
        ) : null}
        {error ? <p className="mt-3 text-sm text-live">{error}</p> : null}
        <button
          type="button"
          disabled={busy}
          onClick={() => void connect()}
          className="mt-4 h-11 w-full rounded-ui bg-accent text-sm font-semibold text-fg disabled:opacity-60"
        >
          {busy ? "Connecting…" : tab === "demo" ? "Use demo library" : "Connect"}
        </button>
      </div>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  placeholder,
  secret,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder: string;
  secret?: boolean;
}) {
  return (
    <label className="grid gap-1 text-sm">
      <span className="text-muted">{label}</span>
      <input
        type={secret ? "password" : "text"}
        value={value}
        placeholder={placeholder}
        onChange={(event) => onChange(event.target.value)}
        className="h-11 rounded-ui border border-line bg-bg px-3 text-fg outline-none placeholder:text-muted focus:border-accent"
        autoComplete="off"
      />
    </label>
  );
}
