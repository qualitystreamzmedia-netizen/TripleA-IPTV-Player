import { useEffect, useRef, useState } from "react";
import { Volume2, VolumeX } from "lucide-react";

type Status = "loading" | "playing" | "error";

export function PreviewPlayer({ url, title }: { url: string; title: string }) {
  const ref = useRef<HTMLVideoElement>(null);
  const [muted, setMuted] = useState(true);
  const [status, setStatus] = useState<Status>("loading");

  useEffect(() => {
    const video = ref.current;
    if (!video) return;
    let dead = false;
    let hls: { destroy: () => void } | null = null;
    setStatus("loading");

    const onPlaying = () => {
      if (!dead) setStatus("playing");
    };
    const onError = () => {
      if (!dead) setStatus("error");
    };

    video.muted = true;
    video.addEventListener("playing", onPlaying);
    video.addEventListener("error", onError);

    (async () => {
      const hlsUrl = /\.m3u8(\?|$)/i.test(url);
      if (hlsUrl) {
        const { default: Hls } = await import("hls.js");
        if (dead) return;
        if (Hls.isSupported()) {
          const player = new Hls({
            enableWorker: true,
            xhrSetup(xhr, requestUrl) {
              xhr.open("GET", `/api/media?url=${encodeURIComponent(requestUrl)}`, true);
            },
          });
          hls = player;
          player.on(Hls.Events.ERROR, (_event, data) => {
            if (data.fatal) onError();
          });
          player.loadSource(url);
          player.attachMedia(video);
          return;
        }
      }
      if (dead) return;
      video.src = `/api/media?url=${encodeURIComponent(url)}`;
      await video.play().catch(() => undefined);
    })().catch(() => onError());

    return () => {
      dead = true;
      video.removeEventListener("playing", onPlaying);
      video.removeEventListener("error", onError);
      hls?.destroy();
      video.removeAttribute("src");
      video.load();
    };
  }, [url]);

  useEffect(() => {
    if (ref.current) ref.current.muted = muted;
  }, [muted]);

  return (
    <div className="relative overflow-hidden rounded-ui bg-black">
      <video
        ref={ref}
        className="aspect-video w-full bg-black object-contain"
        autoPlay
        muted
        playsInline
        aria-label={title}
      />
      {status !== "playing" ? (
        <div className="absolute inset-0 flex items-end bg-bg/40 p-3">
          <p className="text-sm text-fg">
            {status === "error" ? "This stream did not start in the browser." : "Starting…"}
          </p>
        </div>
      ) : null}
      <button
        type="button"
        className="absolute right-2 bottom-2 flex size-11 items-center justify-center rounded-full bg-panel/90 text-fg"
        onClick={() => setMuted((value) => !value)}
        aria-label={muted ? "Unmute" : "Mute"}
      >
        {muted ? <VolumeX className="size-5" /> : <Volume2 className="size-5" />}
      </button>
    </div>
  );
}
