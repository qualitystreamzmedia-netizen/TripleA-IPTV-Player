export type Program = {
  id: string;
  title: string;
  start: number;
  end: number;
  description: string;
};

export type Channel = {
  id: string;
  name: string;
  group: string;
  number: number;
  url: string;
  programs: Program[];
};

export type Source =
  | { mode: "demo" }
  | { mode: "m3u"; url: string }
  | { mode: "xtream"; server: string; username: string; password: string };

const BLOCK = 30 * 60 * 1000;
const STORAGE_KEY = "triplea-iptv-v1";

const SHOWS: Record<string, string[]> = {
  Film: ["Open Reel", "Night Drive", "Second Feature", "Short Subject", "Late Matinee", "Studio Loop"],
  Sport: ["Match Window", "Training Tape", "Highlight Reel", "Court Side", "Lap Times", "Locker Room"],
  News: ["Desk Brief", "Field Note", "Hourly Update", "City Wire", "Weather Slot", "Late Bulletin"],
  Science: ["Orbit Watch", "Lab Hour", "Signal Check", "Deep Field", "Test Pattern", "Mission Loop"],
  Music: ["Session", "Live Room", "Night Shift", "Acoustic Set", "Backline", "Encore"],
  General: ["On Air", "Continuity", "Open Slot", "Station ID", "Feature", "Replay"],
};

function hash(value: string): number {
  let n = 0;
  for (let i = 0; i < value.length; i++) n = (n * 33 + value.charCodeAt(i)) >>> 0;
  return n;
}

export function guidePrograms(channelId: string, group: string, now = Date.now()): Program[] {
  const titles = SHOWS[group] ?? SHOWS.General;
  const origin = now - (now % BLOCK) - BLOCK;
  const salt = hash(channelId);
  const programs: Program[] = [];
  for (let i = 0; i < 12; i++) {
    const start = origin + i * BLOCK;
    const title = titles[(i + salt) % titles.length];
    programs.push({
      id: `${channelId}-${start}`,
      title,
      start,
      end: start + BLOCK,
      description:
        group === "General"
          ? "No programme guide came with this playlist. This slot is a local placeholder."
          : `${title}. Sample guide so the timeline stays readable. Your provider's EPG replaces this when it sends one.`,
    });
  }
  return programs;
}

const DEMO_SEED: Array<Omit<Channel, "programs" | "number">> = [
  {
    id: "bunny",
    name: "Big Buck Bunny",
    group: "Film",
    url: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
  },
  {
    id: "tears",
    name: "Tears of Steel",
    group: "Film",
    url: "https://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8",
  },
  {
    id: "dark",
    name: "Dark Truths",
    group: "Film",
    url: "https://storage.googleapis.com/shaka-demo-assets/bbb-dark-truths-hls/hls.m3u8",
  },
  {
    id: "angel",
    name: "Angel One",
    group: "Music",
    url: "https://storage.googleapis.com/shaka-demo-assets/angel-one-hls/hls.m3u8",
  },
  {
    id: "bipbop",
    name: "Bipbop",
    group: "News",
    url: "https://devstreaming-cdn.apple.com/videos/streaming/examples/img_bipbop_adv_example_fmp4/master.m3u8",
  },
  {
    id: "bipbop-wide",
    name: "Bipbop Wide",
    group: "News",
    url: "https://devstreaming-cdn.apple.com/videos/streaming/examples/bipbop_16x9/bipbop_16x9_variant.m3u8",
  },
  {
    id: "pattern",
    name: "Test Pattern",
    group: "Science",
    url: "https://test-streams.mux.dev/test_001/stream.m3u8",
  },
  {
    id: "nasa",
    name: "NASA TV",
    group: "Science",
    url: "https://ntv1.akamaized.net/hls/live/2014075/NASA-NTV1-HLS/master.m3u8",
  },
  {
    id: "shift",
    name: "Timing Reel",
    group: "Sport",
    url: "https://test-streams.mux.dev/pts_shift/master.m3u8",
  },
  {
    id: "break",
    name: "Break Sample",
    group: "Sport",
    url: "https://test-streams.mux.dev/dai-discontinuity-deltatre/manifest.m3u8",
  },
];

export function demoChannels(now = Date.now()): Channel[] {
  return DEMO_SEED.map((channel, index) => ({
    ...channel,
    number: index + 1,
    programs: guidePrograms(channel.id, channel.group, now),
  }));
}

export function currentProgram(channel: Channel, now: number): Program | undefined {
  return (
    channel.programs.find((program) => program.start <= now && now < program.end) ??
    channel.programs[0]
  );
}

export function nextProgram(channel: Channel, now: number): Program | undefined {
  return channel.programs.find((program) => program.start > now);
}

function attr(line: string, name: string): string {
  const match = line.match(new RegExp(`${name}="([^"]*)"`, "i"));
  return match?.[1]?.trim() ?? "";
}

export function parseM3u(text: string, now = Date.now()): Channel[] {
  const lines = text.split(/\r?\n/);
  const channels: Channel[] = [];
  let pending: { name: string; group: string } | null = null;
  for (const raw of lines) {
    const line = raw.trim();
    if (!line) continue;
    if (line.startsWith("#EXTINF")) {
      const comma = line.lastIndexOf(",");
      const name = (comma >= 0 ? line.slice(comma + 1) : "Channel").trim() || "Channel";
      const group = attr(line, "group-title") || "General";
      pending = { name, group };
      continue;
    }
    if (line.startsWith("#")) continue;
    if (!/^https?:\/\//i.test(line)) {
      pending = null;
      continue;
    }
    const meta = pending ?? { name: `Channel ${channels.length + 1}`, group: "General" };
    const id = `m3u-${channels.length + 1}`;
    channels.push({
      id,
      name: meta.name,
      group: meta.group,
      number: channels.length + 1,
      url: line,
      programs: guidePrograms(id, "General", now),
    });
    pending = null;
  }
  return channels;
}

type XtreamCategory = { category_id?: string | number; category_name?: string };
type XtreamStream = {
  stream_id?: number;
  name?: string;
  category_id?: string | number;
  stream_icon?: string;
};

function serverBase(server: string): string {
  const trimmed = server.trim().replace(/\/+$/, "");
  if (!/^https?:\/\//i.test(trimmed)) return `http://${trimmed}`;
  return trimmed;
}

async function readJson(url: string): Promise<unknown> {
  const response = await fetch(`/api/media?url=${encodeURIComponent(url)}`);
  if (!response.ok) throw new Error(`The server answered ${response.status}.`);
  return response.json();
}

export async function loadXtream(
  server: string,
  username: string,
  password: string,
  now = Date.now(),
): Promise<Channel[]> {
  const base = serverBase(server);
  const auth = `username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`;
  const info = (await readJson(`${base}/player_api.php?${auth}`)) as {
    user_info?: { auth?: number; status?: string };
  };
  if (info?.user_info && info.user_info.auth === 0) {
    throw new Error("That username or password was rejected.");
  }
  const [categories, streams] = (await Promise.all([
    readJson(`${base}/player_api.php?${auth}&action=get_live_categories`),
    readJson(`${base}/player_api.php?${auth}&action=get_live_streams`),
  ])) as [XtreamCategory[], XtreamStream[]];
  if (!Array.isArray(streams)) throw new Error("This server did not return a channel list.");
  const names = new Map<string, string>();
  if (Array.isArray(categories)) {
    for (const category of categories) {
      if (category.category_id != null) {
        names.set(String(category.category_id), category.category_name || "General");
      }
    }
  }
  return streams.slice(0, 4000).map((stream, index) => {
    const id = String(stream.stream_id ?? index + 1);
    const group = names.get(String(stream.category_id ?? "")) || "General";
    return {
      id: `xt-${id}`,
      name: stream.name?.trim() || `Channel ${index + 1}`,
      group,
      number: index + 1,
      url: `${base}/live/${encodeURIComponent(username)}/${encodeURIComponent(password)}/${id}.m3u8`,
      programs: guidePrograms(`xt-${id}`, "General", now),
    };
  });
}

export async function loadM3u(url: string, now = Date.now()): Promise<Channel[]> {
  const response = await fetch(`/api/media?url=${encodeURIComponent(url)}`);
  if (!response.ok) throw new Error(`The playlist answered ${response.status}.`);
  const text = await response.text();
  const channels = parseM3u(text, now);
  if (channels.length === 0) throw new Error("That playlist did not contain any http streams.");
  return channels;
}

export function loadSavedSource(): Source {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { mode: "demo" };
    const parsed = JSON.parse(raw) as Source;
    if (parsed?.mode === "m3u" && parsed.url) return parsed;
    if (parsed?.mode === "xtream" && parsed.server && parsed.username) return parsed;
  } catch {
    /* ignore broken storage */
  }
  return { mode: "demo" };
}

export function saveSource(source: Source) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(source));
}

export function loadFavorites(): string[] {
  try {
    const raw = localStorage.getItem(`${STORAGE_KEY}-favs`);
    const parsed = raw ? (JSON.parse(raw) as unknown) : [];
    return Array.isArray(parsed) ? parsed.filter((item) => typeof item === "string") : [];
  } catch {
    return [];
  }
}

export function saveFavorites(ids: string[]) {
  localStorage.setItem(`${STORAGE_KEY}-favs`, JSON.stringify(ids));
}

export function formatClock(now: number): string {
  return new Intl.DateTimeFormat("en", {
    weekday: "short",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  }).format(now);
}

export function formatTime(stamp: number): string {
  return new Intl.DateTimeFormat("en", { hour: "numeric", minute: "2-digit" }).format(stamp);
}
