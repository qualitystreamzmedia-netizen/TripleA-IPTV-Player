import { createFileRoute } from "@tanstack/react-router";
import { PreviewPlayer } from "@/components/triplea/player";

type PipSearch = { src: string; title: string };

export const Route = createFileRoute("/pip")({
  validateSearch: (search: Record<string, unknown>): PipSearch => ({
    src: typeof search.src === "string" ? search.src : "",
    title: typeof search.title === "string" ? search.title : "TripleA",
  }),
  component: PipWindow,
});

function PipWindow() {
  const search = Route.useSearch();
  if (!search.src) return <div className="h-screen bg-black" />;
  const url = search.src;
  return (
    <div className="h-screen bg-black">
      <PreviewPlayer
        url={url}
        title={search.title || "TripleA"}
        onClose={() => {
          const channel = new BroadcastChannel("triplea-pip");
          channel.postMessage({ type: "close", url });
          channel.close();
          window.close();
        }}
      />
    </div>
  );
}
