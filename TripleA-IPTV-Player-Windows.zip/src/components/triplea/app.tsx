import { useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { Search, Settings, Star, Volume2, VolumeX } from "lucide-react";
import {
  currentProgram,
  demoCatalog,
  formatClock,
  formatTime,
  loadEpisodes,
  loadFavorites,
  loadLibrary,
  loadM3u,
  loadSavedSource,
  loadXtream,
  loadEpg,
  nextProgram,
  playlistLabel,
  programsFor,
  saveFavorites,
  saveLibrary,
  upsertPlaylist,
  type Catalog,
  type Channel,
  type Movie,
  type Playlist,
  type Series,
  type Source,
} from "@/lib/iptv";
import { PreviewPlayer, currentVolume, publishVolume, toggleSharedMute } from "@/components/triplea/player";
import { TitleShelf } from "@/components/triplea/shelf";
import { CategoryEditor } from "@/components/triplea/category-editor";
import { previewAsset } from "@/lib/preview-path-prefix";
import {
  arrangeCategories,
  loadCategoryPrefs,
  playlistNames,
  saveCategoryPrefs,
  type CategoryPrefs,
  type CategorySection,
} from "@/lib/categories";

function titledCatalog(
  kind: "movies" | "series",
  catalog: Catalog,
  libraries: Record<string, Catalog>,
  playlists: Playlist[],
  activeId: string,
  viewId: string,
  query: string,
  searchKind: "channels" | "categories",
): Array<Movie | Series> {
  const q = query.trim().toLowerCase();
  const useAll = playlists.length === 0 || viewId === "all" || q.length > 0;
  const chosen = playlists.filter((item) => useAll || item.id === viewId);
  const lists =
    chosen.length === 0
      ? [kind === "movies" ? catalog.movies : catalog.series]
      : chosen.map((playlist) => {
          const data = libraries[playlist.id] ?? (playlist.id === activeId ? catalog : undefined);
          const items = kind === "movies" ? data?.movies : data?.series;
          return (items ?? []).map((item) => ({ ...item, id: `${playlist.id}::${item.id}` }));
        });
  const rows = lists.flat();
  if (!q) return rows;
  return rows.filter((item) =>
    searchKind === "categories" ? item.group.toLowerCase().includes(q) : item.name.toLowerCase().includes(q),
  );
}

const WINDOW_MS = 3 * 60 * 60 * 1000;
const FULL_GUIDE_MS = 8 * 60 * 60 * 1000;
const FONT_KEY = "triplea-iptv-v1-font";
const VLC_KEY = "triplea-iptv-v1-vlc";
const PLAYER_KEY = "triplea-iptv-v1-player";

type PlayerChoice = "mpegts" | "vlc" | "hls" | "browser";

function channelTitle(name: string): string {
  return name
    .replace(/\bpremium\b/gi, " ")
    .replace(/\bon\s*air\b/gi, " ")
    .replace(/\s{2,}/g, " ")
    .replace(/\s+([|·-])\s*$/g, "")
    .replace(/^\s*[|·-]\s*/g, "")
    .trim();
}

function loadPlayer(): PlayerChoice {
  try {
    if (typeof navigator !== "undefined" && /Android/i.test(navigator.userAgent)) return "browser";
    const saved = localStorage.getItem(PLAYER_KEY);
    if (saved === "mpegts" || saved === "vlc" || saved === "hls" || saved === "browser") return saved;
    if (localStorage.getItem(VLC_KEY) === "1") return "vlc";
  } catch {
    /* keep the default */
  }
  return "mpegts";
}

function savePlayer(value: PlayerChoice) {
  localStorage.setItem(PLAYER_KEY, value);
  localStorage.setItem(VLC_KEY, value === "vlc" ? "1" : "0");
}

function loadFontSize(): number {
  try {
    const value = Number(localStorage.getItem(FONT_KEY));
    if (Number.isFinite(value) && value >= 10 && value <= 18) return value;
  } catch {
    /* keep the default */
  }
  return 12;
}

function saveFontSize(value: number) {
  localStorage.setItem(FONT_KEY, String(value));
}

function hideInstallButtons() {
  if (typeof navigator === "undefined") return false;
  const ua = navigator.userAgent;
  if (/Android/i.test(ua)) return true;
  return /Electron/i.test(ua) && /Macintosh|Mac OS X/i.test(ua);
}

function useNow() {
  const [now, setNow] = useState<number | null>(null);
  useEffect(() => {
    const tick = () => setNow(Date.now());
    tick();
    const id = window.setInterval(tick, 30000);
    return () => window.clearInterval(id);
  }, []);
  return now;
}

export function TripleAApp() {
  const tick = useNow();
  const now = tick ?? 0;
  const [catalog, setCatalog] = useState<Catalog>(() => demoCatalog());
  const [section, setSection] = useState<"live" | "movies" | "series">("live");
  const [openedSections, setOpenedSections] = useState({ movies: false, series: false });
  const [source, setSource] = useState<Source>({ mode: "demo" });
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [activeId, setActiveId] = useState("");
  const [libraries, setLibraries] = useState<Record<string, Catalog>>({});
  const [viewId, setViewId] = useState("all");
  const [searchKind, setSearchKind] = useState<"channels" | "categories">("channels");
  const [group, setGroup] = useState("All");
  const [query, setQuery] = useState("");
  const [selectedId, setSelectedId] = useState<string>("bunny");
  const [favorites, setFavorites] = useState<string[]>([]);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [booted, setBooted] = useState(false);
  const [feature, setFeature] = useState({ url: "", title: "" });
  const [openEpisodes, setOpenEpisodes] = useState<NonNullable<Series["episodes"]>>([]);
  const [loadingSeries, setLoadingSeries] = useState("");
  const [seriesNote, setSeriesNote] = useState("");
  const [refreshing, setRefreshing] = useState(false);
  const [screenOpen, setScreenOpen] = useState(true);
  const [guideState, setGuideState] = useState<"sample" | "loading" | "live" | "empty">("sample");
  const [logo, setLogo] = useState("/logo.png");
  const [categoryPrefs, setCategoryPrefs] = useState(loadCategoryPrefs);
  const [categorySection, setCategorySection] = useState<CategorySection>("live");
  const [fontSize, setFontSize] = useState(12);
  const [useVlc, setUseVlc] = useState(loadPlayer() === "vlc");
  const [player, setPlayer] = useState<PlayerChoice>(loadPlayer);
  const [fullGuide, setFullGuide] = useState(false);
  const [volume, setVolume] = useState(80);
  const [pins, setPins] = useState<{ url: string; title: string; channelId: string }[]>([]);
  const pipWindows = useRef(new Map<string, Window>());
  const [externalPip, setExternalPip] = useState(false);
  const [hideInstalls, setHideInstalls] = useState(false);

  useEffect(() => {
    setHideInstalls(hideInstallButtons());
  }, []);

  useEffect(() => {
    if (!booted) return;
    const timer = window.setTimeout(() => {
      setOpenedSections({ movies: true, series: true });
    }, 300);
    return () => window.clearTimeout(timer);
  }, [booted]);

  useEffect(() => {
    const library = loadLibrary();
    const saved = library.playlists.find((item) => item.id === library.activeId)?.source ?? loadSavedSource();
    const favs = loadFavorites();
    setFavorites(favs);
    setFontSize(loadFontSize());
    setLogo(previewAsset("/logo.png"));
    setPlaylists(library.playlists);
    setActiveId(library.activeId);
    setViewId(library.playlists.length > 1 ? "all" : library.activeId);
    setSource(saved);
    let dead = false;
    const pending = library.playlists.length > 0 ? library.playlists : [];
    if (pending.length === 0) {
      setCatalog(demoCatalog());
      setBooted(true);
      return;
    }
    void Promise.all(
      pending.map(async (playlist) => {
        try {
          const next =
            playlist.source.mode === "demo"
              ? demoCatalog()
              : playlist.source.mode === "m3u"
                ? await loadM3u(playlist.source.url)
                : await loadXtream(playlist.source.server, playlist.source.username, playlist.source.password);
          if (dead) return;
          setLibraries((current) => ({ ...current, [playlist.id]: next }));
          if (playlist.id === library.activeId) {
            setCatalog(next);
            setSelectedId(next.channels[0] ? `${playlist.id}::${next.channels[0].id}` : "");
          }
        } catch {
          if (!dead && playlist.id === library.activeId) {
            setSource({ mode: "demo" });
            setCatalog(demoCatalog());
          }
        }
      }),
    ).finally(() => {
      if (!dead) setBooted(true);
    });
    return () => {
      dead = true;
    };
  }, []);

  useEffect(() => {
    setVolume(currentVolume());
    function onVolume(event: Event) {
      setVolume((event as CustomEvent<number>).detail);
    }
    window.addEventListener("triplea-volume", onVolume);
    return () => window.removeEventListener("triplea-volume", onVolume);
  }, []);

  useEffect(() => {
    const epgUrl = catalog.epgUrl;
    if (!epgUrl) {
      setGuideState("sample");
      return;
    }
    setGuideState("loading");
    let dead = false;
    loadEpg(epgUrl, catalog.channels, Date.now(), (channels) => {
      if (dead) return;
      setGuideState("live");
      setCatalog((current) => (current.epgUrl === epgUrl ? { ...current, channels } : current));
      setLibraries((current) => {
        let changed = false;
        const next = { ...current };
        for (const [id, data] of Object.entries(current)) {
          if (data.epgUrl !== epgUrl) continue;
          next[id] = { ...data, channels };
          changed = true;
        }
        return changed ? next : current;
      });
    })
      .then((channels) => {
        if (dead) return;
        setGuideState(channels.some((channel) => channel.guide === "epg") ? "live" : "empty");
        setCatalog((current) => (current.epgUrl === epgUrl ? { ...current, channels } : current));
        setLibraries((current) => {
          let changed = false;
          const next = { ...current };
          for (const [id, data] of Object.entries(current)) {
            if (data.epgUrl !== epgUrl) continue;
            next[id] = { ...data, channels };
            changed = true;
          }
          return changed ? next : current;
        });
      })
      .catch(() => {
        if (!dead) setGuideState("empty");
      });
    return () => {
      dead = true;
    };
  }, [catalog.epgUrl]);

  const guideJobs = useRef(new Set<string>());
  const guideKey = playlists.map((playlist) => `${playlist.id}:${libraries[playlist.id]?.epgUrl ?? ""}`).join("|");
  useEffect(() => {
    for (const playlist of playlists) {
      const data = libraries[playlist.id];
      if (!data?.epgUrl || playlist.id === activeId) continue;
      const token = `${playlist.id}|${data.epgUrl}`;
      if (guideJobs.current.has(token)) continue;
      guideJobs.current.add(token);
      void loadEpg(data.epgUrl, data.channels, Date.now(), (channels) => {
        setLibraries((current) => {
          const existing = current[playlist.id];
          if (!existing) return current;
          return { ...current, [playlist.id]: { ...existing, channels } };
        });
        setGuideState("live");
      }).catch(() => undefined);
    }
  }, [activeId, guideKey, libraries, playlists]);

  const channels = useMemo(() => {
    const q = query.trim();
    const useAll = playlists.length === 0 || viewId === "all" || q.length > 0;
    const chosen = playlists.filter((item) => useAll || item.id === viewId);
    if (chosen.length === 0) {
      return catalog.channels.map((channel) => ({ ...channel, playlistName: playlistLabel(source) }));
    }
    const guided = new Map(catalog.channels.map((channel) => [channel.id, channel]));
    return chosen.flatMap((playlist) => {
      const data = libraries[playlist.id] ?? (playlist.id === activeId ? catalog : undefined);
      if (!data) return [];
      const playlistName = playlistLabel(playlist.source);
      return data.channels.map((channel) => {
        const fresh = playlist.id === activeId ? guided.get(channel.id) : undefined;
        const sourceChannel = fresh && fresh.programs.length > channel.programs.length ? fresh : channel;
        return {
          ...sourceChannel,
          id: `${playlist.id}::${channel.id}`,
          playlistName,
        };
      });
    });
  }, [activeId, catalog, libraries, playlists, query, source, viewId]);
  const liveCategories = useMemo(
    () => arrangeCategories(playlistNames(channels.map((channel) => channel.group)), categoryPrefs.live),
    [categoryPrefs.live, channels],
  );
  const movieTitles = useMemo(
    () => titledCatalog("movies", catalog, libraries, playlists, activeId, viewId, query, searchKind),
    [activeId, catalog, libraries, playlists, query, searchKind, viewId],
  );
  const seriesTitles = useMemo(
    () => titledCatalog("series", catalog, libraries, playlists, activeId, viewId, query, searchKind),
    [activeId, catalog, libraries, playlists, query, searchKind, viewId],
  );
  const movieCategories = useMemo(
    () => arrangeCategories(playlistNames(movieTitles.map((item) => item.group)), categoryPrefs.movies),
    [categoryPrefs.movies, movieTitles],
  );
  const seriesCategories = useMemo(
    () => arrangeCategories(playlistNames(seriesTitles.map((item) => item.group)), categoryPrefs.series),
    [categoryPrefs.series, seriesTitles],
  );
  const groups = ["All", "Favorites", ...liveCategories
    .filter((category) => {
      const q = query.trim().toLowerCase();
      if (!q || searchKind !== "categories") return true;
      return category.label.toLowerCase().includes(q) || category.id.toLowerCase().includes(q);
    })
    .map((category) => category.id)];

  useEffect(() => {
    if (group !== "All" && group !== "Favorites" && !liveCategories.some((category) => category.id === group)) {
      setGroup("All");
    }
  }, [group, liveCategories]);

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return channels.filter((channel) => {
      if (group === "Favorites" && !favorites.includes(channel.id)) return false;
      if (group !== "All" && group !== "Favorites" && channel.group !== group) return false;
      if (!q) return true;
      if (searchKind === "categories") return channel.group.toLowerCase().includes(q);
      return channel.name.toLowerCase().includes(q) || String(channel.number).includes(q);
    });
  }, [channels, favorites, group, query, searchKind]);

  const selected = channels.find((channel) => channel.id === selectedId) ?? visible[0] ?? channels[0];

  useEffect(() => {
    const channel = new BroadcastChannel("triplea-pip");
    channel.onmessage = (event) => {
      const url = event.data?.url;
      if (event.data?.type !== "close" || typeof url !== "string") return;
      pipWindows.current.delete(url);
      if (pipWindows.current.size === 0) setExternalPip(false);
      setPins((current) => {
        const pin = current.find((item) => item.url === url);
        if (pin) {
          const match = channels.find((item) => item.url === pin.url || item.id === pin.channelId);
          if (match) {
            setSection("live");
            setSelectedId(match.id);
            setScreenOpen(true);
          } else {
            setFeature({ url: pin.url, title: pin.title });
          }
        }
        return current.filter((item) => item.url !== url);
      });
    };
    return () => channel.close();
  }, [channels]);

  function closePin(pin: { url: string; title: string; channelId: string }) {
    setPins((current) => current.filter((item) => item.url !== pin.url));
    const channel = channels.find((item) => item.url === pin.url || item.id === pin.channelId);
    if (channel) {
      setSection("live");
      setSelectedId(channel.id);
      setScreenOpen(true);
      return;
    }
    setFeature({ url: pin.url, title: pin.title });
  }

  function togglePin(url: string, title: string, channelId = "") {
    if (!url) return;
    const existing = pins.find((pin) => pin.url === url);
    if (existing) {
      pipWindows.current.get(url)?.close();
      pipWindows.current.delete(url);
      if (pipWindows.current.size === 0) setExternalPip(false);
      closePin(existing);
      return;
    }
    setPins((current) => {
      const next = [...current, { url, title, channelId }];
      return next.length > 3 ? next.slice(next.length - 3) : next;
    });
    if (selected?.url === url) setScreenOpen(false);
    if (feature.url === url) setFeature({ url: "", title: "" });
    const desktop = typeof navigator !== "undefined" && /Electron/i.test(navigator.userAgent);
    if (!desktop) return;
    const page = `${window.location.origin}/pip?src=${encodeURIComponent(url)}&title=${encodeURIComponent(title)}`;
    const pip = window.open(page, `triplea-pip-${encodeURIComponent(url)}`, "popup=yes,width=420,height=270");
    if (pip) {
      pipWindows.current.set(url, pip);
      setExternalPip(true);
    }
  }
  const onNow = selected ? currentProgram(selected, now) : undefined;
  const coming = selected ? nextProgram(selected, now) : undefined;
  const windowStart = now - (now % (30 * 60 * 1000));

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      const target = event.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) return;
      if (section !== "live" || !visible.length) return;
      const index = visible.findIndex((channel) => channel.id === selected?.id);
      if (event.key === "ArrowDown") {
        event.preventDefault();
        setSelectedId(visible[index < 0 ? 0 : (index + 1) % visible.length].id);
        setScreenOpen(true);
      } else if (event.key === "ArrowUp") {
        event.preventDefault();
        setSelectedId(visible[index < 0 ? visible.length - 1 : (index - 1 + visible.length) % visible.length].id);
        setScreenOpen(true);
      } else if (event.key === "f" || event.key === "F") {
        if (selected) toggleFavorite(selected.id);
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  function stepChannel(delta: number) {
    if (!visible.length) return;
    const index = visible.findIndex((channel) => channel.id === selected?.id);
    const next = index < 0 ? (delta > 0 ? 0 : visible.length - 1) : (index + delta + visible.length) % visible.length;
    setSelectedId(visible[next].id);
    setScreenOpen(true);
  }

  function updateCategoryPrefs(section: CategorySection, next: CategoryPrefs) {
    setCategoryPrefs((current) => {
      const prefs = { ...current, [section]: next };
      saveCategoryPrefs(prefs);
      return prefs;
    });
  }

  function categoryTitle(id: string) {
    if (id === "All" || id === "Favorites") return id;
    return liveCategories.find((category) => category.id === id)?.label ?? id;
  }

  function toggleFavorite(id: string) {
    setFavorites((current) => {
      const next = current.includes(id) ? current.filter((item) => item !== id) : [...current, id];
      saveFavorites(next);
      return next;
    });
  }

  function applyCatalog(next: Catalog, nextSource: Source) {
    const library = upsertPlaylist(nextSource);
    setPlaylists(library.playlists);
    setActiveId(library.activeId);
    saveLibrary(library.activeId, library.playlists);
    setLibraries((current) => ({ ...current, [library.activeId]: next }));
    setViewId(library.activeId);
    setCatalog(next);
    setSource(nextSource);
    setSection("live");
    setGroup("All");
    setQuery("");
    setSelectedId(next.channels[0] ? `${library.activeId}::${next.channels[0].id}` : "");
    setFeature({ url: "", title: "" });
    setOpenEpisodes([]);
    setSettingsOpen(false);
  }

  async function refreshPlaylist(id: string) {
    const targets = playlists.filter((playlist) => id === "all" || playlist.id === id);
    if (targets.length === 0) return;
    setRefreshing(true);
    try {
      await Promise.all(
        targets.map(async (item) => {
          const previous = libraries[item.id];
          guideJobs.current.delete(`${item.id}|${previous?.epgUrl ?? ""}`);
          const next =
            item.source.mode === "demo"
              ? demoCatalog()
              : item.source.mode === "m3u"
                ? await loadM3u(item.source.url)
                : await loadXtream(item.source.server, item.source.username, item.source.password);
          if (next.epgUrl) guideJobs.current.add(`${item.id}|${next.epgUrl}`);
          setLibraries((current) => ({ ...current, [item.id]: next }));
          if (item.id === activeId) {
            setCatalog(next);
            setSelectedId((current) =>
              next.channels.some((channel) => `${item.id}::${channel.id}` === current)
                ? current
                : next.channels[0]
                  ? `${item.id}::${next.channels[0].id}`
                  : "",
            );
          }
          if (!next.epgUrl) return;
          void loadEpg(next.epgUrl, next.channels, Date.now(), (channels) => {
            setLibraries((current) => {
              const existing = current[item.id];
              if (!existing) return current;
              return { ...current, [item.id]: { ...existing, channels } };
            });
            if (item.id === activeId) {
              setCatalog((current) => (current.epgUrl === next.epgUrl ? { ...current, channels } : current));
            }
            setGuideState("live");
          });
        }),
      );
    } catch {
      setSeriesNote("That playlist could not be refreshed.");
    } finally {
      setRefreshing(false);
    }
  }

  async function selectPlaylist(id: string) {
    const item = playlists.find((playlist) => playlist.id === id);
    if (!item) return;
    setActiveId(id);
    setViewId(id);
    saveLibrary(id, playlists);
    setSource(item.source);
    setSettingsOpen(false);
    setSection("live");
    setGroup("All");
    setQuery("");
    try {
      const next =
        item.source.mode === "demo"
          ? demoCatalog()
          : item.source.mode === "m3u"
            ? await loadM3u(item.source.url)
            : await loadXtream(item.source.server, item.source.username, item.source.password);
      setLibraries((current) => ({ ...current, [item.id]: next }));
      setCatalog(next);
      setSelectedId(next.channels[0] ? `${id}::${next.channels[0].id}` : "");
      setFeature({ url: "", title: "" });
      setOpenEpisodes([]);
    } catch {
      setSeriesNote("That playlist could not be loaded.");
    }
  }

  function openSeries(item: Series) {
    const splitAt = item.id.indexOf("::");
    const playlistId = splitAt >= 0 ? item.id.slice(0, splitAt) : "";
    const rawId = splitAt >= 0 ? item.id.slice(splitAt + 2) : item.id;
    const owner = playlists.find((playlist) => playlist.id === playlistId)?.source ?? source;
    setSeriesNote("");
    if (item.episodes) {
      setOpenEpisodes(item.episodes);
      setLoadingSeries("");
      return;
    }
    setOpenEpisodes([]);
    setLoadingSeries(item.id);
    void loadEpisodes(owner, rawId)
      .then((episodes) => {
        setOpenEpisodes(episodes);
        if (episodes.length === 0) setSeriesNote("This series did not list any episodes.");
      })
      .catch((caught: unknown) => {
        setSeriesNote(caught instanceof Error ? caught.message : "Could not load episodes.");
      })
      .finally(() => setLoadingSeries(""));
  }

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      const target = event.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) return;
      if (!["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(event.key)) return;
      const items = [...document.querySelectorAll<HTMLElement>("a[href], button, input, select, textarea")].filter(
        (item) => !item.hasAttribute("disabled") && item.tabIndex !== -1 && item.getClientRects().length > 0,
      );
      if (!items.length) return;
      const current = items.indexOf(document.activeElement as HTMLElement);
      const step = event.key === "ArrowDown" || event.key === "ArrowRight" ? 1 : -1;
      const next = current < 0 ? 0 : (current + step + items.length) % items.length;
      items[next]?.focus();
      event.preventDefault();
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const searchPlaceholder =
    searchKind === "categories"
      ? "Search categories in all playlists"
      : section === "live"
        ? "Search channels in all playlists"
        : section === "movies"
          ? "Search movies in all playlists"
          : "Search series in all playlists";

  return (
    <main className="relative flex h-full min-h-0 flex-col overflow-hidden border-[7px] border-black text-fg shadow-[inset_0_0_0_2px_#d4b15a]">
      <header className="flex flex-col gap-1 border-b border-black bg-black px-3 py-1.5 text-white sm:px-4">
        <div className="flex items-center gap-2">
          <div className="flex shrink-0 items-center gap-2">
            <img src={logo} alt="" className="h-7 w-auto" />
            <div className="leading-tight">
              <p className="text-xs font-semibold tracking-wide">TripleA</p>
              <p className="text-[10px] text-white/60">IPTV Player</p>
            </div>
          </div>
          {playlists.length > 0 ? (
            <select
              value={playlists.length > 1 ? viewId : playlists[0].id}
              aria-label="Playlist"
              onChange={(event) => {
                const next = event.target.value;
                setGroup("All");
                if (next === "all") {
                  setViewId("all");
                  return;
                }
                void selectPlaylist(next);
              }}
              className="h-8 max-w-[10rem] rounded-ui border border-white/20 bg-[#171e33] px-2 text-xs text-white"
            >
              {playlists.length > 1 ? <option value="all">All playlists</option> : null}
              {playlists.map((item) => (
                <option key={item.id} value={item.id}>
                  {playlistLabel(item.source)}
                </option>
              ))}
            </select>
          ) : null}
          {playlists.length > 0 ? (
            <button
              type="button"
              disabled={refreshing}
              onClick={() => void refreshPlaylist(playlists.length > 1 ? viewId : playlists[0].id)}
              className="h-8 shrink-0 rounded-ui bg-[#14804a] px-2 text-xs font-semibold text-white disabled:opacity-60"
            >
              {refreshing ? "Refreshing…" : "Refresh"}
            </button>
          ) : null}
          <select
            value={player}
            aria-label="Player"
            onChange={(event) => {
              const next = event.target.value as PlayerChoice;
              setPlayer(next);
              setUseVlc(next === "vlc");
              savePlayer(next);
            }}
            className="h-8 shrink-0 rounded-ui border border-white/20 bg-[#171e33] px-2 text-xs font-semibold text-white"
            style={{ colorScheme: "dark" }}
          >
            <option value="mpegts" style={{ backgroundColor: "#171e33", color: "#ffffff" }}>TS</option>
            <option value="vlc" style={{ backgroundColor: "#171e33", color: "#ffffff" }}>VLC</option>
            <option value="hls" style={{ backgroundColor: "#171e33", color: "#ffffff" }}>HLS</option>
            <option value="browser" style={{ backgroundColor: "#171e33", color: "#ffffff" }}>Web</option>
          </select>
          <button
            type="button"
            onClick={() => {
              setSection("live");
              setFullGuide(true);
            }}
            className="h-8 shrink-0 rounded-ui bg-[#2f6bff] px-2 text-xs font-semibold text-white"
          >
            Guide
          </button>
          <label className="relative hidden w-44 sm:block">
            <Search className="pointer-events-none absolute top-1/2 left-2 size-3.5 -translate-y-1/2 text-white/70" />
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder={searchPlaceholder}
              className="h-8 w-full rounded-ui border border-white/20 bg-[#171e33] pr-2 pl-7 text-xs text-white outline-none placeholder:text-white/50 focus:border-[#2f6bff]"
              aria-label={searchPlaceholder}
            />
          </label>
          <select
            value={searchKind}
            aria-label="Search in"
            onChange={(event) => setSearchKind(event.target.value as "channels" | "categories")}
            className="h-8 rounded-ui border border-white/20 bg-[#2f6bff] px-2 text-xs font-semibold text-white"
          >
            <option value="channels">{section === "live" ? "Channels" : "Titles"}</option>
            <option value="categories">Categories</option>
          </select>
          <div className="ml-auto flex items-center gap-2">
            <p className="hidden text-xs text-white/70 lg:block">{tick ? formatClock(tick) : "Live guide"}</p>
            {hideInstalls ? null : (
              <>
            <a
              href={previewAsset("/TripleA-IPTV-Setup.exe")}
              download="TripleA-IPTV-Setup.exe"
              className="flex h-4 shrink-0 items-center rounded px-0.5 text-[8px] leading-none font-medium text-white bg-[#2f6bff]"
            >
              Windows
            </a>
            <a
              href={previewAsset("/TripleA-Mac-Setup.command")}
              download="TripleA-Mac-Setup.command"
              className="flex h-4 shrink-0 items-center rounded px-0.5 text-[8px] leading-none font-medium text-white bg-[#1aa6c4]"
            >
              Mac
            </a>
            <a
              href={previewAsset("/TripleA-IPTV.apk")}
              download="TripleA-IPTV.apk"
              className="flex h-4 shrink-0 items-center rounded px-0.5 text-[8px] leading-none font-medium text-white bg-[#e07a14]"
            >
              Fire TV
            </a>
              </>
            )}
            <button
              type="button"
              className="flex size-8 items-center justify-center rounded-ui bg-[#7a3ff0] text-white"
              onClick={() => setSettingsOpen(true)}
              aria-label="Sources and settings"
            >
              <Settings className="size-4" />
            </button>
          </div>
        </div>
      </header>

      <label className="relative mx-3 mt-3 sm:hidden">
        <Search className="pointer-events-none absolute top-1/2 left-2 size-3.5 -translate-y-1/2 text-muted" />
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder={searchPlaceholder}
          className="h-8 w-full rounded-ui border border-line bg-panel pr-2 pl-7 text-xs outline-none placeholder:text-muted focus:border-accent"
          aria-label={searchPlaceholder}
        />
      </label>

      <div
        className={
          section === "live"
            ? "flex gap-1 border-b border-black bg-black px-3 py-2 sm:hidden"
            : "flex gap-1 border-b border-black bg-black px-3 py-2"
        }
        role="tablist"
        aria-label="Library"
      >
        {(
          [
            ["live", "Live"],
            ["movies", "Movies"],
            ["series", "Series"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            role="tab"
            aria-selected={section === id}
            onClick={() => {
              setSection(id);
              setGroup("All");
            }}
            className={
              id === "movies"
                ? section === id
                  ? "h-11 flex-1 rounded-ui bg-[#7a3ff0] text-sm font-medium text-white sm:flex-none sm:px-4"
                  : "h-11 flex-1 rounded-ui bg-[#7a3ff0]/70 text-sm text-white sm:flex-none sm:px-4"
                : id === "series"
                  ? section === id
                    ? "h-11 flex-1 rounded-ui bg-[#14804a] text-sm font-medium text-white sm:flex-none sm:px-4"
                    : "h-11 flex-1 rounded-ui bg-[#14804a]/70 text-sm text-white sm:flex-none sm:px-4"
                  : section === id
                    ? "h-11 flex-1 rounded-ui bg-[#2f6bff] text-sm font-medium text-white sm:flex-none sm:px-4"
                    : "h-11 flex-1 rounded-ui bg-[#2f6bff]/70 text-sm text-white sm:flex-none sm:px-4"
            }
          >
            {label}
          </button>
        ))}
      </div>

      <div className={section === "live" ? "grid min-h-0 flex-1 grid-cols-1 grid-rows-[auto_auto_minmax(0,1fr)] sm:grid-cols-[6.25rem_9rem_minmax(0,1fr)] sm:grid-rows-[auto_minmax(0,1fr)]" : "hidden"}>
          <div className="hidden items-center gap-1 border-b border-black bg-black px-2 py-1.5 sm:col-span-2 sm:row-start-1 sm:flex" role="tablist" aria-label="Library">
            {(
              [
                ["live", "Live"],
                ["movies", "Movies"],
                ["series", "Series"],
              ] as const
            ).map(([id, label]) => {
              const selected = section === id;
              return (
              <button
                key={id}
                type="button"
                role="tab"
                aria-selected={selected}
                onClick={() => {
                  setSection(id);
                  setGroup("All");
                }}
                className={
                  id === "movies"
                    ? selected
                      ? "h-9 rounded-ui bg-[#7a3ff0] px-3 text-sm font-medium text-white"
                      : "h-9 rounded-ui bg-[#7a3ff0]/70 px-3 text-sm text-white"
                    : id === "series"
                      ? selected
                        ? "h-9 rounded-ui bg-[#14804a] px-3 text-sm font-medium text-white"
                        : "h-9 rounded-ui bg-[#14804a]/70 px-3 text-sm text-white"
                      : selected
                        ? "h-9 rounded-ui bg-[#2f6bff] px-3 text-sm font-medium text-white"
                        : "h-9 rounded-ui bg-[#2f6bff]/70 px-3 text-sm text-white"
                }
              >
                {label}
              </button>
              );
            })}
          </div>
          <nav className="panel-frame hidden min-h-0 flex-col gap-0.5 overflow-y-auto bg-[#12182c] p-1 text-white sm:col-start-1 sm:row-start-2 sm:flex" aria-label="Groups">
            {groups.map((name) => (
              <button
                key={name}
                type="button"
                onClick={() => setGroup(name)}
                className={
                  name === group
                    ? "rounded-ui bg-accent px-1.5 py-1 text-left text-[11px] leading-tight font-medium text-white"
                    : "rounded-ui px-1.5 py-1 text-left text-[11px] leading-tight text-white/90 hover:bg-white/10 hover:text-white"
                }
              >
                {categoryTitle(name)}
                {name === "Favorites" ? ` (${favorites.length})` : ""}
              </button>
            ))}
          </nav>

          <div className="flex gap-2 overflow-x-auto px-3 py-2 sm:hidden">
            {groups.map((name) => (
              <button
                key={name}
                type="button"
                onClick={() => setGroup(name)}
                className={
                  name === group
                    ? "shrink-0 rounded-full bg-accent px-3 py-2 text-sm text-white"
                    : "shrink-0 rounded-full bg-panel px-3 py-2 text-sm text-muted"
                }
              >
                {categoryTitle(name)}
              </button>
            ))}
          </div>

          <div className="stage-dark grid h-full min-h-0 sm:col-start-3 sm:row-span-2 sm:row-start-1 sm:grid-cols-[minmax(0,1fr)_6.5rem] sm:grid-rows-[minmax(0,1fr)_8.75rem] sm:border-l sm:border-line">
          <section className="relative h-full min-h-56 overflow-hidden sm:col-start-1 sm:row-start-1 sm:min-h-0">
            {selected && screenOpen && !pins.some((pin) => pin.url === selected.url) ? (
              <div className="absolute inset-0">
                <PreviewPlayer
                  url={selected.url}
                  title={selected.name}
                  onPrevious={() => stepChannel(-1)}
                  onNext={() => stepChannel(1)}
                  onClose={() => setScreenOpen(false)}
                  onPin={() => togglePin(selected.url, selected.name, selected.id)}
                  pinned={pins.some((pin) => pin.url === selected.url)}
                  vlc={useVlc}
                  player={player}
                />
                <div className="pointer-events-none absolute bottom-8 left-2 z-20 max-w-[70%] rounded bg-bg/70 px-2 py-1 sm:hidden">
                  <p className="truncate text-[10px] tracking-wide text-accent uppercase">
                    {selected?.playlistName || playlistLabel(source)}
                  </p>
                  <h1 className="truncate text-xs font-semibold">{onNow?.title ? channelTitle(onNow.title) : channelTitle(selected?.name ?? "") || "TripleA"}</h1>
                  <p className="truncate text-[10px] text-muted">
                    {selected ? `${selected.number}  ${channelTitle(selected.name)}` : "No channel"}
                  </p>
                </div>
              </div>
            ) : selected && pins.some((pin) => pin.url === selected.url) ? (
              <p className="flex h-11 items-center px-2 text-sm text-muted">Playing in a small window</p>
            ) : selected ? (
              <button
                type="button"
                className="m-2 flex h-11 items-center rounded-ui bg-panel px-4 text-sm font-medium"
                onClick={() => setScreenOpen(true)}
              >
                Open screen
              </button>
            ) : null}
          </section>
          <aside className="panel-frame hidden min-h-0 flex-col gap-1 overflow-y-auto p-1.5 sm:col-start-2 sm:row-start-1 sm:flex" aria-label="Program description">
            <p className="text-[9px] tracking-wide text-accent uppercase">{selected?.playlistName || playlistLabel(source)}</p>
            <p className="text-[10px] leading-tight text-muted">{selected ? `${selected.number}  ${channelTitle(selected.name)}` : "No channel"}</p>
            <h1 className="text-[11px] leading-snug font-semibold">{onNow?.title ? channelTitle(onNow.title) : channelTitle(selected?.name ?? "") || "TripleA"}</h1>
            {onNow ? (
              <p className="text-[9px] text-muted">
                {formatTime(onNow.start)} – {formatTime(onNow.end)}
              </p>
            ) : null}
            <p className="text-[9px] leading-snug font-bold text-muted">{onNow?.description || "No description for this program."}</p>
            {coming ? (
              <p className="text-[10px] leading-snug">
                <span className="text-muted">Next </span>
                {coming.title}
              </p>
            ) : null}
          </aside>

          <section className="panel-frame h-full min-h-0 overflow-auto sm:col-span-2 sm:row-start-2">
            <Guide
              channels={visible}
              now={now}
              windowStart={windowStart}
              guideState={guideState}
              selectedId={selected?.id}
              onSelect={(id) => {
                setSelectedId(id);
                setScreenOpen(true);
              }}
            />
          </section>
          </div>

          <section className="panel-frame min-h-0 overflow-y-auto bg-[#1636b0] text-white sm:col-start-2 sm:row-start-2" aria-label="Channels">
            {visible.length === 0 ? (
              <p className="p-4 text-sm text-white/80">{booted ? "No channels in this group." : "Loading channels…"}</p>
            ) : (
              <ul>
                {visible.map((channel) => {
                  const active = channel.id === selected?.id;
                  const program = currentProgram(channel, now);
                  return (
                    <li
                      key={channel.id}
                      className={active ? "flex items-stretch bg-white text-[#1636b0]" : "flex items-stretch hover:bg-white/15"}
                    >
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedId(channel.id);
                          setScreenOpen(true);
                        }}
                        className="flex min-w-0 flex-1 items-center gap-1 px-1 py-0.5 text-left"
                      >
                        <span className={active ? "w-5 shrink-0 text-[10px] leading-tight text-[#1636b0]/70 tabular-nums" : "w-5 shrink-0 text-[10px] leading-tight text-white/70 tabular-nums"}>
                          {channel.number}
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className={active ? "block truncate text-[10px] leading-tight font-semibold text-[#1636b0]" : "block truncate text-[10px] leading-tight font-semibold text-white"}>
                            {channelTitle(channel.name)}
                          </span>
                          {program?.title ? (
                            <span className={active ? "block truncate text-[9px] leading-tight text-[#1636b0]/70" : "block truncate text-[9px] leading-tight text-white/75"}>
                              {channelTitle(program.title)}
                            </span>
                          ) : null}
                        </span>
                      </button>
                      <button
                        type="button"
                        aria-pressed={favorites.includes(channel.id)}
                        aria-label={favorites.includes(channel.id) ? "Remove favorite" : "Add favorite"}
                        className="flex size-5 shrink-0 items-center justify-center"
                        onClick={() => toggleFavorite(channel.id)}
                      >
                        <Star
                          className={
                            favorites.includes(channel.id)
                              ? "size-3 fill-[#f0d78c] text-[#f0d78c]"
                              : active
                                ? "size-3 text-[#1636b0]/60"
                                : "size-3 text-white/70"
                          }
                        />
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
          </section>
        </div>
      {openedSections.movies ? (
        <div className={section === "movies" ? "flex min-h-0 flex-1 flex-col" : "hidden"}>
          <TitleShelf
            kind="movies"
            items={movieTitles}
            categories={movieCategories}
            query=""
            favorites={favorites}
            episodes={openEpisodes}
            loadingId={loadingSeries}
            note={seriesNote}
            playingUrl={section === "movies" ? feature.url : ""}
            playingTitle={feature.title}
            onToggleFavorite={toggleFavorite}
            onPlay={(url, title) => setFeature({ url, title })}
            onOpen={openSeries}
            onPin={togglePin}
            pinnedUrls={pins.map((pin) => pin.url)}
            vlc={useVlc}
            player={player}
          />
        </div>
      ) : null}
      {openedSections.series ? (
        <div className={section === "series" ? "flex min-h-0 flex-1 flex-col" : "hidden"}>
          <TitleShelf
            kind="series"
            items={seriesTitles}
            categories={seriesCategories}
            query=""
            favorites={favorites}
            episodes={openEpisodes}
            loadingId={loadingSeries}
            note={seriesNote}
            playingUrl={section === "series" ? feature.url : ""}
            playingTitle={feature.title}
            onToggleFavorite={toggleFavorite}
            onPlay={(url, title) => setFeature({ url, title })}
            onOpen={openSeries}
            onPin={togglePin}
            pinnedUrls={pins.map((pin) => pin.url)}
            vlc={useVlc}
            player={player}
          />
        </div>
      ) : null}

      {typeof document === "undefined" || externalPip
        ? null
        : createPortal(
            pins.map((pin, index) => (
              <PreviewPlayer
                key={pin.url}
                url={pin.url}
                title={pin.title}
                floatIndex={index}
                vlc={useVlc}
                player={player}
                onClose={() => closePin(pin)}
              />
            )),
            document.body,
          )}

      {settingsOpen ? (
        <SourceDialog
          source={source}
          playlists={playlists}
          activeId={activeId}
          onSelectPlaylist={(id) => void selectPlaylist(id)}
          catalog={catalog}
          categorySection={categorySection}
          categoryPrefs={categoryPrefs[categorySection]}
          fontSize={fontSize}
          onFontSize={(next) => {
            setFontSize(next);
            saveFontSize(next);
          }}
          useVlc={player === "vlc"}
          onVlc={(next) => {
            const value: PlayerChoice = next ? "vlc" : "mpegts";
            setPlayer(value);
            setUseVlc(next);
            savePlayer(value);
          }}
          onCategorySection={setCategorySection}
          onCategoryPrefs={(next) => updateCategoryPrefs(categorySection, next)}
          onClose={() => setSettingsOpen(false)}
          onApply={applyCatalog}
        />
      ) : null}
      {fullGuide && section === "live" ? (
        <div className="pointer-events-auto absolute top-auto right-2 bottom-8 left-2 z-40 flex h-[52%] flex-col overflow-hidden rounded-ui border border-line bg-bg/95 shadow-2xl sm:top-14 sm:right-auto sm:h-auto sm:w-[min(62%,calc(100%-20rem))]">
          <div className="flex flex-wrap items-center gap-2 border-b border-line px-3 py-2">
            <h2 className="text-sm font-semibold">Full guide</h2>
            {playlists.length > 0 ? (
              <select
                value={playlists.length > 1 ? viewId : playlists[0].id}
                aria-label="Guide playlist"
                onChange={(event) => {
                  const next = event.target.value;
                  setGroup("All");
                  if (next === "all") {
                    setViewId("all");
                    return;
                  }
                  void selectPlaylist(next);
                }}
                className="h-8 max-w-[11rem] rounded-ui border border-line bg-panel px-2 text-xs"
              >
                {playlists.length > 1 ? <option value="all">All playlists</option> : null}
                {playlists.map((item) => (
                  <option key={item.id} value={item.id}>
                    {playlistLabel(item.source)}
                  </option>
                ))}
              </select>
            ) : null}
            <select
              value={groups.includes(group) ? group : "All"}
              aria-label="Guide category"
              onChange={(event) => setGroup(event.target.value)}
              className="h-8 max-w-[12rem] rounded-ui border border-line bg-panel px-2 text-xs"
            >
              {groups.map((name) => (
                <option key={name} value={name}>
                  {categoryTitle(name)}
                  {name === "Favorites" ? ` (${favorites.length})` : ""}
                </option>
              ))}
            </select>
            <button
              type="button"
              onClick={() => setFullGuide(false)}
              className="ml-auto h-8 rounded-ui bg-panel-2 px-3 text-xs font-semibold"
            >
              Close
            </button>
          </div>
          <div className="min-h-0 flex-1 overflow-auto">
            <Guide
              channels={visible}
              now={now}
              windowStart={windowStart}
              span={FULL_GUIDE_MS}
              guideState={guideState}
              selectedId={selected?.id}
              onSelect={(id) => {
                setSelectedId(id);
                setScreenOpen(true);
              }}
            />
          </div>
        </div>
      ) : null}
      <div className="flex h-6 shrink-0 items-center gap-2 border-t border-line bg-panel px-2">
        <button
          type="button"
          className="flex size-5 shrink-0 items-center justify-center text-fg"
          onClick={() => toggleSharedMute()}
          aria-label={volume === 0 ? "Unmute" : "Mute"}
        >
          {volume === 0 ? <VolumeX className="size-3" /> : <Volume2 className="size-3" />}
        </button>
        <label className="flex min-w-0 flex-1 items-center">
          <span className="sr-only">Volume {volume}</span>
          <input
            type="range"
            min={0}
            max={100}
            value={volume}
            aria-label="Volume"
            className="volume-bar w-full"
            onChange={(event) => publishVolume(Number(event.target.value))}
          />
        </label>
      </div>
    </main>
  );
}

function Guide({
  channels,
  now,
  windowStart,
  span = WINDOW_MS,
  guideState,
  selectedId,
  onSelect,
}: {
  channels: Channel[];
  now: number;
  windowStart: number;
  span?: number;
  guideState: "sample" | "loading" | "live" | "empty";
  selectedId?: string;
  onSelect: (id: string) => void;
}) {
  const hours = Math.max(1, Math.round(span / (60 * 60 * 1000)));
  const ticks = Array.from({ length: hours + 1 }, (_, hour) => windowStart + hour * 60 * 60 * 1000);
  const clock = now > 0 ? now : 0;
  const title =
    guideState === "live" ? "Guide" : guideState === "loading" ? "Loading guide" : guideState === "empty" ? "No listing" : "Sample guide";
  const nowLeft = clock > 0 ? ((clock - windowStart) / span) * 100 : -1;
  return (
    <div className={span > WINDOW_MS ? "min-w-[72rem]" : "min-w-[34rem]"}>
      <div className="sticky top-0 z-20 grid grid-cols-[5.5rem_minmax(0,1fr)] border-b border-line bg-panel text-[9px] text-muted">
        <span className="sticky left-0 bg-panel px-1.5 py-1">{title}</span>
        <div className="relative h-5">
          {ticks.map((mark) => (
            <span key={mark} className="absolute top-1 whitespace-nowrap" style={{ left: `${((mark - windowStart) / span) * 100}%` }}>
              {formatTime(mark)}
            </span>
          ))}
        </div>
      </div>
      <ul>
        {channels.map((channel) => (
          <li key={channel.id} className="grid grid-cols-[5.5rem_minmax(0,1fr)] border-b border-line">
            <button
              type="button"
              className={
                channel.id === selectedId
                  ? "sticky left-0 truncate bg-panel px-1.5 py-0.5 text-left text-[9px] leading-tight font-medium text-fg"
                  : "sticky left-0 truncate bg-bg px-1.5 py-0.5 text-left text-[9px] leading-tight text-muted"
              }
              onClick={() => onSelect(channel.id)}
            >
              {channelTitle(channel.name)}
            </button>
            <div className="relative h-6">
              {(() => {
                const listed = programsFor(channel, clock);
                const blocks = listed.filter(
                  (program) => program.end > windowStart && program.start < windowStart + span,
                );
                const nearest =
                  blocks.length > 0
                    ? null
                    : (listed.find((program) => program.end > clock) ?? listed[listed.length - 1]);
                if (!nearest && blocks.length === 0) {
                  return (
                    <span className="absolute inset-y-0.5 right-1 left-1 flex items-center rounded-md bg-panel-2 px-1 text-[9px] text-muted">
                      No listing
                    </span>
                  );
                }
                const shown = blocks.length > 0 ? blocks : nearest ? [nearest] : [];
                return shown.map((program) => {
                  const start = Math.max(program.start, windowStart);
                  const end = Math.min(program.end, windowStart + span);
                  const left = blocks.length > 0 ? ((start - windowStart) / span) * 100 : 0;
                  const width = blocks.length > 0 ? Math.max(0, ((end - start) / span) * 100) : 100;
                  const live = program.start <= clock && clock < program.end;
                  return (
                    <button
                      key={program.id}
                      type="button"
                      onClick={() => onSelect(channel.id)}
                      className={
                        live
                          ? "absolute top-0.5 bottom-0.5 flex items-center overflow-hidden rounded-md bg-accent px-1 text-left text-[9px] leading-none text-fg"
                          : "absolute top-0.5 bottom-0.5 flex items-center overflow-hidden rounded-md bg-panel-2 px-1 text-left text-[9px] leading-none text-muted"
                      }
                      style={{ left: `${left}%`, width: `calc(${width}% - 3px)` }}
                      title={`${program.title}${program.description ? ` — ${program.description}` : ""}`}
                    >
                      <span className="truncate">{program.title}</span>
                    </button>
                  );
                });
              })()}
              {nowLeft >= 0 && nowLeft <= 100 ? (
                <span className="pointer-events-none absolute top-0 bottom-0 z-10 w-px bg-live" style={{ left: `${nowLeft}%` }} aria-hidden="true" />
              ) : null}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

function SourceDialog({
  source,
  playlists,
  activeId,
  onSelectPlaylist,
  catalog,
  categorySection,
  categoryPrefs,
  fontSize,
  onFontSize,
  useVlc,
  onVlc,
  onCategorySection,
  onCategoryPrefs,
  onClose,
  onApply,
}: {
  source: Source;
  playlists: Playlist[];
  activeId: string;
  onSelectPlaylist: (id: string) => void;
  catalog: Catalog;
  categorySection: CategorySection;
  categoryPrefs: CategoryPrefs;
  fontSize: number;
  onFontSize: (size: number) => void;
  useVlc: boolean;
  onVlc: (value: boolean) => void;
  onCategorySection: (section: CategorySection) => void;
  onCategoryPrefs: (prefs: CategoryPrefs) => void;
  onClose: () => void;
  onApply: (catalog: Catalog, source: Source) => void;
}) {
  const [tab, setTab] = useState<Source["mode"]>(source.mode);
  const [m3u, setM3u] = useState(source.mode === "m3u" ? source.url : "");
  const [server, setServer] = useState(source.mode === "xtream" ? source.server : "");
  const [username, setUsername] = useState(source.mode === "xtream" ? source.username : "");
  const [password, setPassword] = useState(source.mode === "xtream" ? source.password : "");
  const [playlistName, setPlaylistName] = useState(source.mode === "demo" ? "" : (source.name ?? ""));
  const [error, setError] = useState("");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);

  function namedSource(): Source {
    const name = playlistName.trim();
    if (tab === "demo") return { mode: "demo" };
    if (tab === "m3u") return { mode: "m3u", url: m3u.trim(), ...(name ? { name } : {}) };
    return {
      mode: "xtream",
      server: server.trim(),
      username: username.trim(),
      password,
      ...(name ? { name } : {}),
    };
  }

  async function loadCurrent() {
    if (tab === "demo") return demoCatalog();
    if (tab === "m3u") return loadM3u(m3u.trim());
    return loadXtream(server.trim(), username.trim(), password);
  }

  async function testConnection() {
    setError("");
    setNote("");
    setBusy(true);
    try {
      const next = await loadCurrent();
      setNote(
        `Connected. ${next.channels.length} live channels, ${next.movies.length} movies, ${next.series.length} series.`,
      );
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Could not reach that source.");
    } finally {
      setBusy(false);
    }
  }

  async function connect() {
    setError("");
    setNote("");
    setBusy(true);
    try {
      onApply(await loadCurrent(), namedSource());
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Could not load that source.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center p-3 sm:items-center" role="dialog" aria-modal="true" aria-labelledby="source-title">
      <button type="button" className="absolute inset-0 bg-bg/80" aria-label="Close settings" onClick={onClose} />
      <div className="relative z-10 max-h-[85vh] w-full max-w-lg overflow-y-auto rounded-ui border border-line bg-panel p-4 shadow-2xl">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h2 id="source-title" className="text-lg font-semibold">Sources</h2>
            <p className="mt-1 text-sm text-muted">
              TripleA plays your own Xtream login or M3U link. The demo library is public sample video, not a channel package.
            </p>
          </div>
          <button type="button" className="rounded-ui px-3 py-2 text-sm text-muted hover:text-fg" onClick={onClose}>
            Close
          </button>
        </div>
        {playlists.length > 1 ? (
          <label className="mt-4 grid gap-1 text-sm">
            <span className="text-muted">Playlist</span>
            <select
              value={activeId}
              aria-label="Playlist"
              onChange={(event) => onSelectPlaylist(event.target.value)}
              className="h-11 rounded-ui border border-line bg-bg px-3 text-fg"
            >
              {playlists.map((item) => (
                <option key={item.id} value={item.id}>
                  {playlistLabel(item.source)}
                </option>
              ))}
            </select>
          </label>
        ) : null}
        <div className="mt-4 grid grid-cols-3 gap-2" role="tablist">
          {(
            [
              ["demo", "Demo"],
              ["xtream", "Xtream"],
              ["m3u", "M3U"],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              role="tab"
              aria-selected={tab === id}
              onClick={() => setTab(id)}
              className={
                tab === id
                  ? "h-11 rounded-ui bg-accent text-sm font-medium text-white"
                  : "h-11 rounded-ui bg-panel-2 text-sm text-muted"
              }
            >
              {label}
            </button>
          ))}
        </div>
        {tab === "xtream" ? (
          <div className="mt-4 grid gap-3">
            <Field label="Playlist name" value={playlistName} onChange={setPlaylistName} placeholder="Home" />
            <Field label="Xtream address" value={server} onChange={setServer} placeholder="http://example.com:8080" />
            <p className="-mt-1 text-xs text-muted">
              Or paste a GitHub file link. The file should contain the Xtream address on one line, such as http://example.com:8080.
            </p>
            <Field label="Username" value={username} onChange={setUsername} placeholder="username" />
            <Field label="Password" value={password} onChange={setPassword} placeholder="password" secret />
          </div>
        ) : null}
        {tab === "m3u" ? (
          <div className="mt-4 grid gap-3">
            <Field label="Playlist name" value={playlistName} onChange={setPlaylistName} placeholder="Home" />
            <Field label="Playlist URL" value={m3u} onChange={setM3u} placeholder="https://example.com/list.m3u" />
          </div>
        ) : null}
        {tab === "demo" ? (
          <p className="mt-4 text-sm text-muted">
            Open movies and test patterns you can play immediately. Arrow keys change channel. F favorites the selected one.
          </p>
        ) : null}
        {error ? <p className="mt-3 text-sm text-live">{error}</p> : null}
        {note ? <p className="mt-3 text-sm text-fg">{note}</p> : null}
        {tab === "demo" ? null : (
          <button
            type="button"
            disabled={busy}
            onClick={() => void testConnection()}
            className="mt-4 h-11 w-full rounded-ui border border-line text-sm font-semibold text-fg disabled:opacity-60"
          >
            {busy ? "Checking…" : "Test connection"}
          </button>
        )}
        <button
          type="button"
          disabled={busy}
          onClick={() => void connect()}
          className="mt-4 h-11 w-full rounded-ui bg-accent text-sm font-semibold text-white disabled:opacity-60"
        >
          {busy ? "Connecting…" : tab === "demo" ? "Use demo library" : "Connect"}
        </button>
        <button
          type="button"
          aria-pressed={useVlc}
          onClick={() => onVlc(!useVlc)}
          className="mt-4 flex h-11 w-full items-center justify-between rounded-ui border border-line px-3 text-sm"
        >
          <span>VLC player</span>
          <span className={useVlc ? "text-fg" : "text-muted"}>{useVlc ? "On" : "Off"}</span>
        </button>
        <label className="mt-4 grid gap-1 text-sm">
          <span className="flex items-center justify-between text-muted">
            Channel list size
            <span className="text-fg tabular-nums">{fontSize}px</span>
          </span>
          <input
            type="range"
            min={10}
            max={18}
            step={1}
            value={fontSize}
            aria-label="Channel list font size"
            className="volume-bar w-full"
            onChange={(event) => onFontSize(Number(event.target.value))}
          />
        </label>
        <CategoryEditor
          section={categorySection}
          onSection={onCategorySection}
          names={
            categorySection === "live"
              ? playlistNames(catalog.channels.map((channel) => channel.group))
              : categorySection === "movies"
                ? playlistNames(catalog.movies.map((item) => item.group))
                : playlistNames(catalog.series.map((item) => item.group))
          }
          prefs={categoryPrefs}
          onChange={onCategoryPrefs}
        />
      </div>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  placeholder,
  secret,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder: string;
  secret?: boolean;
}) {
  const [visible, setVisible] = useState(false);
  return (
    <label className="grid gap-1 text-sm">
      <span className="flex items-center justify-between text-muted">
        {label}
        {secret ? (
          <button type="button" className="text-xs text-fg" onClick={() => setVisible((current) => !current)}>
            {visible ? "Hide" : "Show"}
          </button>
        ) : null}
      </span>
      <input
        type={secret && !visible ? "password" : "text"}
        value={value}
        placeholder={placeholder}
        onChange={(event) => onChange(event.target.value)}
        className="h-11 rounded-ui border border-line bg-bg px-3 text-fg outline-none placeholder:text-muted focus:border-accent"
        autoComplete="off"
      />
    </label>
  );
}
