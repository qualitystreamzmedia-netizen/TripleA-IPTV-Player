const { app, BrowserWindow } = require("electron");
const { spawn } = require("node:child_process");
const http = require("node:http");

const port = 8080;
let server;

function waitForServer() {
  return new Promise((resolve) => {
    const tick = () => {
      const request = http.get(`http://127.0.0.1:${port}/`, (response) => {
        response.resume();
        resolve();
      });
      request.on("error", () => setTimeout(tick, 400));
    };
    tick();
  });
}

function openWindow() {
  const window = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 900,
    minHeight: 600,
    title: "TripleA IPTV Player",
    backgroundColor: "#0b0d12",
    autoHideMenuBar: true,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
    },
  });
  window.loadURL(`http://127.0.0.1:${port}/`);
}

app.whenReady().then(async () => {
  const npm = process.platform === "win32" ? "npm.cmd" : "npm";
  server = spawn(npm, ["run", "dev"], {
    cwd: app.getAppPath(),
    stdio: "inherit",
    env: process.env,
    shell: process.platform === "win32",
  });
  await waitForServer();
  openWindow();
});

app.on("window-all-closed", () => {
  if (server) server.kill();
  app.quit();
});
