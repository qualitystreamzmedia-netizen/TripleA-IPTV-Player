import { useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from "react";
import type { LoaderCallbacks, LoaderConfiguration, LoaderContext } from "hls.js";
import { Maximize2, Minimize2, Pause, PictureInPicture2, Play, SkipBack, SkipForward, Volume2, VolumeX, X } from "lucide-react";
import { previewAsset } from "@/lib/preview-path-prefix";

type Status = "loading" | "playing" | "error" | "tap";

let rememberedVolume = 80;
let lastAudible = 80;

function mediaUrl(target: string): string {
  if (target.includes("/api/media?url=")) return target;
  return `${previewAsset("/api/media")}?url=${encodeURIComponent(target)}`;
}

export function PreviewPlayer({
  url,
  title,
  onPrevious,
  onNext,
  onClose,
  onPin,
  pinned = false,
  floatIndex,
  timeline = false,
}: {
  url: string;
  title: string;
  onPrevious?: () => void;
  onNext?: () => void;
  onClose?: () => void;
  onPin?: () => void;
  pinned?: boolean;
  floatIndex?: number;
  timeline?: boolean;
}) {
  const ref = useRef<HTMLVideoElement>(null);
  const boxRef = useRef<HTMLDivElement>(null);
  const volumeRef = useRef(rememberedVolume);
  const [volume, setVolume] = useState(rememberedVolume);
  const [status, setStatus] = useState<Status>("loading");
  const [mode, setMode] = useState<"normal" | "pip" | "full">("normal");
  const [paused, setPaused] = useState(true);
  const [position, setPosition] = useState(0);
  const [duration, setDuration] = useState(0);
  const floating = floatIndex !== undefined || mode === "pip";
  const [spot, setSpot] = useState<{ x: number; y: number } | null>(null);
  const [pipWidth, setPipWidth] = useState(288);
  const drag = useRef<{ dx: number; dy: number } | null>(null);
  const resize = useRef<{ x: number; width: number } | null>(null);
  const scrubbing = useRef(false);
  const wanted = useRef<number | null>(null);
  const seekTries = useRef(0);
  const seekTimer = useRef<number | null>(null);
  const hold = useRef(false);
  const timelineRef = useRef(timeline);
  timelineRef.current = timeline;

  function applyVolume(next: number) {
    const value = Math.min(100, Math.max(0, Math.round(next)));
    rememberedVolume = value;
    if (value > 0) lastAudible = value;
    volumeRef.current = value;
    setVolume(value);
    const video = ref.current;
    if (!video) return;
    video.volume = value / 100;
    video.muted = value === 0;
  }

  function play() {
    const video = ref.current;
    if (!video) return;
    hold.current = false;
    video.volume = volumeRef.current / 100;
    video.muted = volumeRef.current === 0;
    void video.play().then(
      () => setStatus("playing"),
      () => setStatus("error"),
    );
  }

  function pause() {
    hold.current = true;
    ref.current?.pause();
    setPaused(true);
  }

  function seek(value: number) {
    const video = ref.current;
    if (!video || !Number.isFinite(value)) return;
    wanted.current = value;
    scrubbing.current = true;
    seekTries.current = 0;
    setPosition(value);
    const place = () => {
      const node = ref.current;
      if (!node || wanted.current !== value) return;
      if (Math.abs((node.currentTime || 0) - value) > 1) node.currentTime = value;
    };
    place();
    window.setTimeout(place, 350);
  }

  function previewSeek(value: number) {
    wanted.current = value;
    scrubbing.current = true;
    setPosition(value);
    if (seekTimer.current) window.clearTimeout(seekTimer.current);
    seekTimer.current = window.setTimeout(() => seek(value), 180);
  }

  async function closeScreen() {
    if (document.fullscreenElement) await document.exitFullscreen().catch(() => undefined);
    if (document.pictureInPictureElement) await document.exitPictureInPicture().catch(() => undefined);
    setMode("normal");
    pause();
    onClose?.();
  }

  async function togglePip() {
    if (onPin) {
      onPin();
      return;
    }
    const video = ref.current;
    if (!video) return;
    if (mode === "pip" || document.pictureInPictureElement === video) {
      if (document.pictureInPictureElement) await document.exitPictureInPicture().catch(() => undefined);
      setMode("normal");
      return;
    }
    if (document.pictureInPictureEnabled) {
      try {
        await video.requestPictureInPicture();
        return;
      } catch {
        /* The preview frame blocks the browser window, so float the player instead. */
      }
    }
    setMode("pip");
  }

  async function toggleFull() {
    const box = boxRef.current;
    if (mode === "full" || document.fullscreenElement) {
      if (document.fullscreenElement) await document.exitFullscreen().catch(() => undefined);
      setMode("normal");
      return;
    }
    setMode("full");
    try {
      await box?.requestFullscreen();
    } catch {
      /* In-page full screen is already on. */
    }
  }

  useEffect(() => {
    const video = ref.current;
    if (!video) return;
    let dead = false;
    let hls: {
      destroy: () => void;
      startLoad: (startPosition?: number) => void;
      recoverMediaError: () => void;
    } | null = null;
    let retries = 0;
    setStatus("loading");
    setPosition(0);
    setDuration(0);

    const onPlaying = () => {
      if (!dead) {
        setStatus("playing");
        setPaused(false);
      }
    };
    const onPause = () => {
      if (!dead) setPaused(true);
    };
    const keepGoing = () => {
      if (dead || timelineRef.current || hold.current) return;
      if (hls) hls.startLoad(-1);
      else if (Number.isFinite(video.duration)) video.currentTime = 0;
      void video.play().catch(() => undefined);
    };
    const start = () => {
      video.volume = volumeRef.current / 100;
      video.muted = volumeRef.current === 0;
      video.play().then(
        () => {
          if (!dead) setStatus("playing");
        },
        () => {
          if (!dead) setStatus("tap");
        },
      );
    };
    const onTime = () => {
      if (dead || !timelineRef.current) return;
      const length = video.duration;
      if (Number.isFinite(length) && length > 0) setDuration(length);
      const pending = wanted.current;
      if (pending != null) {
        if (Math.abs((video.currentTime || 0) - pending) < 1.5) {
          wanted.current = null;
          scrubbing.current = false;
          setPosition(video.currentTime || 0);
        } else if (!video.seeking && pending > 5 && (video.currentTime || 0) + 2 < pending && seekTries.current < 5) {
          seekTries.current += 1;
          video.currentTime = pending;
        }
        return;
      }
      if (scrubbing.current || video.seeking) return;
      setPosition(video.currentTime || 0);
    };

    video.volume = volumeRef.current / 100;
    video.muted = volumeRef.current === 0;
    video.addEventListener("playing", onPlaying);
    video.addEventListener("pause", onPause);
    video.addEventListener("ended", keepGoing);
    const onSeeked = () => {
      scrubbing.current = false;
    };
    video.addEventListener("timeupdate", onTime);
    video.addEventListener("durationchange", onTime);
    const hideCaptions = () => {
      const tracks = video.textTracks;
      for (let i = 0; i < tracks.length; i += 1) tracks[i].mode = "disabled";
    };
    hideCaptions();
    video.textTracks.addEventListener("addtrack", hideCaptions);
    video.addEventListener("seeked", onSeeked);

    let lastTime = 0;
    let lastMove = Date.now();
    const watch = window.setInterval(() => {
      if (dead || hold.current || video.seeking || timelineRef.current) return;
      const time = video.currentTime || 0;
      if (time > lastTime + 0.15) {
        lastTime = time;
        lastMove = Date.now();
        retries = 0;
        return;
      }
      if (Date.now() - lastMove < 12000) return;
      lastMove = Date.now();
      hls?.startLoad(-1);
      void video.play().catch(() => undefined);
    }, 2000);

    (async () => {
      const hlsUrl = /\.m3u8(\?|$)/i.test(url);
      if (hlsUrl) {
        const { default: Hls } = await import("hls.js");
        if (dead) return;
        if (Hls.isSupported()) {
          const BaseLoader = Hls.DefaultConfig.loader;
          class ProxyLoader extends BaseLoader {
            load(context: LoaderContext, config: LoaderConfiguration, callbacks: LoaderCallbacks<LoaderContext>) {
              if (context?.url && !context.url.includes("/api/media?url=")) context.url = mediaUrl(context.url);
              super.load(context, config, callbacks);
            }
          }
          const player = new Hls({
            enableWorker: true,
            lowLatencyMode: false,
            capLevelToPlayerSize: true,
            maxBufferLength: 30,
            maxMaxBufferLength: 60,
            backBufferLength: 30,
            maxBufferHole: 0.5,
            nudgeMaxRetry: 10,
            liveSyncDurationCount: 3,
            liveMaxLatencyDurationCount: 10,
            liveDurationInfinity: !timelineRef.current,
            enableCEA708Captions: false,
            enableWebVTT: false,
            renderTextTracksNatively: false,
            manifestLoadingTimeOut: 20000,
            manifestLoadingMaxRetry: 6,
            levelLoadingTimeOut: 20000,
            levelLoadingMaxRetry: 8,
            fragLoadingTimeOut: 30000,
            fragLoadingMaxRetry: 8,
            loader: ProxyLoader,
          });
          hls = player;
          player.on(Hls.Events.ERROR, (_event, data) => {
            if (!data.fatal || dead) return;
            retries += 1;
            if (retries > 8 && timelineRef.current) {
              if (!dead) setStatus("error");
              return;
            }
            if (data.type === Hls.ErrorTypes.MEDIA_ERROR) player.recoverMediaError();
            else player.startLoad(-1);
            void video.play().catch(() => undefined);
          });
          player.on(Hls.Events.MANIFEST_PARSED, () => start());
          player.loadSource(url);
          player.attachMedia(video);
          return;
        }
      }
      if (dead) return;
      video.src = mediaUrl(url);
      video.addEventListener("loadeddata", start, { once: true });
    })().catch(() => {
      if (!dead) setStatus("error");
    });

    return () => {
      dead = true;
      window.clearInterval(watch);
      video.removeEventListener("playing", onPlaying);
      video.removeEventListener("pause", onPause);
      video.removeEventListener("ended", keepGoing);
      video.removeEventListener("timeupdate", onTime);
      video.removeEventListener("durationchange", onTime);
      video.removeEventListener("seeked", onSeeked);
      video.textTracks.removeEventListener("addtrack", hideCaptions);
      hls?.destroy();
      video.pause();
      video.removeAttribute("src");
      video.load();
    };
  }, [url]);

  useEffect(() => {
    function onFull() {
      if (!document.fullscreenElement) setMode((current) => (current === "full" ? "normal" : current));
    }
    function onLeavePip() {
      setMode((current) => (current === "pip" ? "normal" : current));
    }
    document.addEventListener("fullscreenchange", onFull);
    document.addEventListener("leavepictureinpicture", onLeavePip);
    return () => {
      document.removeEventListener("fullscreenchange", onFull);
      document.removeEventListener("leavepictureinpicture", onLeavePip);
    };
  }, []);

  useEffect(() => {
    if (mode === "normal") return;
    function onKey(event: KeyboardEvent) {
      if (event.key === "Escape") setMode("normal");
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [mode]);

  useEffect(() => {
    if (floatIndex === undefined && mode !== "pip") return;
    const width = 288;
    const index = floatIndex ?? 0;
    setSpot({
      x: Math.max(8, window.innerWidth - width - 12 - index * (width + 12)),
      y: 64,
    });
  }, [floatIndex, mode]);

  function onDragStart(event: ReactPointerEvent<HTMLDivElement>) {
    if (!spot) return;
    const target = event.target as HTMLElement;
    if (target.closest("button, input, label")) return;
    drag.current = { dx: event.clientX - spot.x, dy: event.clientY - spot.y };
    event.currentTarget.setPointerCapture(event.pointerId);
  }

  function onDragMove(event: ReactPointerEvent<HTMLDivElement>) {
    if (!drag.current) return;
    const width = boxRef.current?.offsetWidth ?? 288;
    const height = boxRef.current?.offsetHeight ?? 160;
    setSpot({
      x: Math.min(Math.max(0, window.innerWidth - width), Math.max(0, event.clientX - drag.current.dx)),
      y: Math.min(Math.max(0, window.innerHeight - height), Math.max(0, event.clientY - drag.current.dy)),
    });
  }

  function onDragEnd() {
    drag.current = null;
  }

  function onResizeStart(event: ReactPointerEvent<HTMLButtonElement>) {
    event.stopPropagation();
    resize.current = { x: event.clientX, width: pipWidth };
    event.currentTarget.setPointerCapture(event.pointerId);
  }

  function onResizeMove(event: ReactPointerEvent<HTMLButtonElement>) {
    if (!resize.current) return;
    const next = resize.current.width + (event.clientX - resize.current.x);
    setPipWidth(Math.min(Math.round(window.innerWidth * 0.85), Math.max(200, Math.round(next))));
  }

  function onResizeEnd() {
    resize.current = null;
  }

  const frame = floating
    ? "fixed z-[70] cursor-grab touch-none overflow-hidden rounded-ui bg-black shadow-2xl ring-1 ring-accent select-none active:cursor-grabbing"
    : mode === "full"
      ? "fixed inset-0 z-50 bg-black"
      : "relative overflow-hidden rounded-ui bg-black";

  const iconButton = "flex size-7 shrink-0 items-center justify-center text-fg";

  return (
    <div
      ref={boxRef}
      className={frame}
      style={floating && spot ? { left: spot.x, top: spot.y, width: pipWidth } : undefined}
    >
      <div
        className={mode === "full" ? "relative h-full" : "relative"}
        onPointerDown={floating ? onDragStart : undefined}
        onPointerMove={floating ? onDragMove : undefined}
        onPointerUp={floating ? onDragEnd : undefined}
      >
      <button
        type="button"
        className="absolute top-1.5 right-1.5 z-40 flex size-7 items-center justify-center rounded-full bg-panel/90 text-fg"
        onClick={(event) => {
          event.stopPropagation();
          void closeScreen();
        }}
        aria-label="Close screen"
      >
        <X className="size-3.5" />
      </button>
      {floatIndex === undefined ? (
        <button
          type="button"
          className="absolute top-9 right-1.5 z-40 flex size-7 items-center justify-center rounded-full bg-panel/90 text-fg"
          onClick={(event) => {
            event.stopPropagation();
            void togglePip();
          }}
          aria-pressed={pinned || mode === "pip"}
          aria-label={pinned ? "Remove picture in picture" : "Picture in picture"}
        >
          <PictureInPicture2 className="size-3.5" />
        </button>
      ) : (
        <p className="absolute top-1.5 left-2 z-40 max-w-[70%] truncate text-[10px] text-fg">{title}</p>
      )}
      <video
        ref={ref}
        className={
          mode === "full"
            ? "pointer-events-none h-full w-full bg-black object-contain"
            : mode === "pip"
              ? "pointer-events-none aspect-video w-full bg-black object-cover"
              : "pointer-events-none aspect-video w-full bg-black object-cover"
        }
        autoPlay
        playsInline
        aria-label={title}
      />
      {floating ? (
        <button
          type="button"
          className="absolute right-0 bottom-0 z-40 size-6 cursor-nwse-resize"
          onPointerDown={onResizeStart}
          onPointerMove={onResizeMove}
          onPointerUp={onResizeEnd}
          aria-label="Resize picture"
        >
          <span className="absolute right-1.5 bottom-1.5 size-2 border-r-2 border-b-2 border-fg" />
        </button>
      ) : null}
      {status !== "playing" ? (
        <button
          type="button"
          className="absolute inset-y-0 left-0 right-12 z-10 flex items-end bg-bg/40 p-3 text-left"
          onClick={(event) => {
            event.stopPropagation();
            play();
          }}
        >
          <span className="text-sm text-fg">
            {status === "error"
              ? "This stream did not start. Try another title."
              : status === "tap"
                ? "Tap to play"
                : "Starting…"}
          </span>
        </button>
      ) : null}
      {timeline ? (
        <div className="absolute right-12 bottom-1.5 left-2 z-30 flex items-center gap-2 rounded-full bg-panel/90 px-2">
          <span className="w-10 shrink-0 text-[10px] text-fg tabular-nums">{clock(position)}</span>
          <label className="flex h-7 min-w-0 flex-1 items-center">
            <span className="sr-only">Timeline</span>
            <input
              type="range"
              min={0}
              max={duration > 0 ? duration : 0}
              step={1}
              value={duration > 0 ? Math.min(position, duration) : 0}
              aria-label="Timeline"
              className="w-full accent-accent"
              onPointerDown={() => {
                scrubbing.current = true;
              }}
              onChange={(event) => previewSeek(Number(event.target.value))}
              onKeyUp={(event) => {
                if (event.key.startsWith("Arrow") || event.key === "Home" || event.key === "End") {
                  seek(Number(event.currentTarget.value));
                }
              }}
            />
          </label>
          <span className="w-10 shrink-0 text-right text-[10px] text-fg tabular-nums">{clock(duration)}</span>
        </div>
      ) : null}
      <div className="absolute top-16 right-1 bottom-1 z-30 flex flex-col items-center gap-0.5 overflow-y-auto rounded-full bg-panel/80 px-0.5 py-1">
        {onPrevious ? (
          <button
            type="button"
            className={iconButton}
            onClick={(event) => {
              event.stopPropagation();
              onPrevious();
            }}
            aria-label="Previous channel"
          >
            <SkipBack className="size-3.5" />
          </button>
        ) : null}
        <button
          type="button"
          className={iconButton}
          onClick={(event) => {
            event.stopPropagation();
            if (paused) play();
            else pause();
          }}
          aria-pressed={!paused}
          aria-label={paused ? "Play" : "Pause"}
        >
          {paused ? <Play className="size-3.5 fill-current" /> : <Pause className="size-3.5 fill-current" />}
        </button>
        {onNext ? (
          <button
            type="button"
            className={iconButton}
            onClick={(event) => {
              event.stopPropagation();
              onNext();
            }}
            aria-label="Next channel"
          >
            <SkipForward className="size-3.5" />
          </button>
        ) : null}
        <button
          type="button"
          className={iconButton}
          onClick={() => applyVolume(volume === 0 ? lastAudible : 0)}
          aria-label={volume === 0 ? "Unmute" : "Mute"}
        >
          {volume === 0 ? <VolumeX className="size-3.5" /> : <Volume2 className="size-3.5" />}
        </button>
        <label className="flex w-7 items-center justify-center py-1">
          <span className="sr-only">Volume {volume}</span>
          <input
            type="range"
            min={0}
            max={100}
            value={volume}
            aria-label="Volume"
            className="volume-bar volume-up"
            onChange={(event) => applyVolume(Number(event.target.value))}
          />
        </label>
        {floatIndex === undefined ? (
        <button
          type="button"
          className={iconButton}
          onClick={() => void toggleFull()}
          aria-pressed={mode === "full"}
          aria-label={mode === "full" ? "Exit full screen" : "Full screen"}
        >
          {mode === "full" ? <Minimize2 className="size-3.5" /> : <Maximize2 className="size-3.5" />}
        </button>
        ) : null}
      </div>
      </div>
    </div>
  );
}

function clock(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) return "0:00";
  const whole = Math.floor(seconds);
  const secondsPart = whole % 60;
  const minutes = Math.floor(whole / 60) % 60;
  const hours = Math.floor(whole / 3600);
  const pad = (value: number) => String(value).padStart(2, "0");
  if (hours > 0) return `${hours}:${pad(minutes)}:${pad(secondsPart)}`;
  return `${minutes}:${pad(secondsPart)}`;
}
