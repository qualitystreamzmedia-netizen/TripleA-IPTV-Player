import { useMemo, useState } from "react";
import { Check, Play, Plus } from "lucide-react";
import { previewAsset } from "@/lib/preview-path-prefix";
import type { Episode, Movie, Series } from "@/lib/iptv";
import type { CategoryView } from "@/lib/categories";
import { PreviewPlayer } from "@/components/triplea/player";

type Item = Movie | Series;

const CARD_TONES = ["#1a3148", "#1c3a34", "#3a2844", "#3a311c", "#243044", "#2c2438"];

export function TitleShelf({
  kind,
  items,
  categories,
  query,
  favorites,
  episodes,
  loadingId,
  note,
  playingUrl,
  playingTitle,
  onToggleFavorite,
  onPlay,
  onOpen,
  onPin,
  pinnedUrls = [],
}: {
  kind: "movies" | "series";
  items: Item[];
  categories: CategoryView[];
  query: string;
  favorites: string[];
  episodes: Episode[];
  loadingId: string;
  note: string;
  playingUrl: string;
  playingTitle: string;
  onToggleFavorite: (id: string) => void;
  onPlay: (url: string, title: string) => void;
  onOpen: (item: Series) => void;
  onPin?: (url: string, title: string) => void;
  pinnedUrls?: string[];
}) {
  const [selectedId, setSelectedId] = useState("");
  const [season, setSeason] = useState(0);
  const [category, setCategory] = useState("All");

  const allowed = useMemo(() => {
    const ids = new Set(categories.map((category) => category.id));
    return items.filter((item) => ids.has(item.group));
  }, [categories, items]);

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return allowed;
    return allowed.filter(
      (item) => item.name.toLowerCase().includes(q) || item.group.toLowerCase().includes(q),
    );
  }, [allowed, query]);

  const rows = useMemo(() => {
    const saved = visible.filter((item) => favorites.includes(item.id));
    const grouped = categories
      .map((category) => ({
        id: category.id,
        title: category.label,
        list: visible.filter((item) => item.group === category.id),
      }))
      .filter((row) => row.list.length > 0);
    return saved.length ? [{ id: "my-list", title: "My List", list: saved }, ...grouped] : grouped;
  }, [categories, favorites, visible]);

  const selected = visible.find((item) => item.id === selectedId) ?? visible[0] ?? null;
  const seasons = Array.from(new Set(episodes.map((episode) => episode.season))).sort((a, b) => a - b);
  const shown = season === 0 ? episodes : episodes.filter((episode) => episode.season === season);
  const empty =
    kind === "movies"
      ? "No movies in this source. An Xtream login loads the movie catalog. An M3U link is live channels only."
      : "No series in this source. An Xtream login loads the series catalog. An M3U link is live channels only.";

  function choose(item: Item) {
    setSelectedId(item.id);
    setSeason(0);
    if ("url" in item) onPlay(item.url, item.name);
    else onOpen(item);
  }

  function playFeatured() {
    if (!selected) return;
    if ("url" in selected) {
      onPlay(selected.url, selected.name);
      return;
    }
    onOpen(selected);
    const first = selected.episodes?.[0];
    if (first) onPlay(first.url, `${selected.name} · ${first.title}`);
  }

  const shownRows = category === "All" ? rows : rows.filter((row) => row.id === category);

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex gap-2 overflow-x-auto border-b border-line px-4 py-2" aria-label="Categories">
        <SeasonChip label="All" active={category === "All"} onClick={() => setCategory("All")} />
        {rows.map((row) => (
          <SeasonChip
            key={row.id}
            label={row.title}
            active={category === row.id}
            onClick={() => setCategory(row.id)}
          />
        ))}
      </div>
      <div className="min-h-0 flex-1 overflow-y-auto">
      {selected ? (
        <section className="relative overflow-hidden bg-[radial-gradient(ellipse_at_20%_0%,#1e3a5f_0%,transparent_55%),linear-gradient(#141820,#0b0d12)] px-4 py-6 sm:px-8">
          <div className="grid items-end gap-5 lg:grid-cols-[minmax(0,24rem)_minmax(0,1fr)]">
            {playingUrl ? (
              <PreviewPlayer
                url={playingUrl}
                title={playingTitle || selected.name}
                onClose={() => onPlay("", "")}
                onPin={onPin ? () => onPin(playingUrl, playingTitle || selected.name) : undefined}
                pinned={pinnedUrls.includes(playingUrl)}
                timeline
              />
            ) : null}
            <div className={playingUrl ? "" : "max-w-2xl py-6 sm:py-10"}>
              <p className="text-xs font-semibold tracking-[0.16em] text-muted uppercase">{selected.group}</p>
              <h2 className="mt-2 text-3xl font-semibold tracking-tight sm:text-5xl">{selected.name}</h2>
              <p className="mt-3 max-w-xl text-sm text-muted sm:text-base">
                {selected.plot || (kind === "movies" ? "Play this title." : "Open this series, then pick an episode.")}
              </p>
              <div className="mt-5 flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={playFeatured}
                  className="flex h-11 items-center gap-2 rounded-md bg-fg px-4 text-sm font-semibold text-bg"
                >
                  <Play className="size-4 fill-current" />
                  Play
                </button>
                <button
                  type="button"
                  onClick={() => onToggleFavorite(selected.id)}
                  aria-pressed={favorites.includes(selected.id)}
                  className="flex h-11 items-center gap-2 rounded-md bg-panel-2 px-4 text-sm font-semibold text-fg"
                >
                  {favorites.includes(selected.id) ? <Check className="size-4" /> : <Plus className="size-4" />}
                  My List
                </button>
              </div>
            </div>
          </div>
        </section>
      ) : (
        <p className="p-6 text-sm text-muted">{empty}</p>
      )}

      {kind === "series" && selected ? (
        <section className="px-4 pt-4 sm:px-8">
          <div className="flex items-center gap-3">
            <h3 className="text-lg font-semibold">Episodes</h3>
            {loadingId === selected.id ? <span className="text-sm text-muted">Loading…</span> : null}
          </div>
          {note ? <p className="mt-2 text-sm text-live">{note}</p> : null}
          {seasons.length > 1 ? (
            <div className="mt-2 flex gap-2 overflow-x-auto">
              <SeasonChip label="All" active={season === 0} onClick={() => setSeason(0)} />
              {seasons.map((value) => (
                <SeasonChip
                  key={value}
                  label={`Season ${value}`}
                  active={season === value}
                  onClick={() => setSeason(value)}
                />
              ))}
            </div>
          ) : null}
          {shown.length ? (
            <ul className="mt-3 flex gap-3 overflow-x-auto pb-2">
              {shown.map((episode) => (
                <li key={episode.id} className="w-56 shrink-0 sm:w-64">
                  <button
                    type="button"
                    className="w-full text-left"
                    onClick={() => onPlay(episode.url, `${selected.name} · ${episode.title}`)}
                  >
                    <span className="flex aspect-video items-end rounded-md bg-panel-2 p-3 text-sm font-semibold">
                      S{episode.season} E{episode.number}
                    </span>
                    <span className="mt-2 block truncate text-sm">{episode.title}</span>
                  </button>
                </li>
              ))}
            </ul>
          ) : null}
        </section>
      ) : null}

      <div className={category === "All" ? "space-y-6 px-4 py-6 sm:px-8" : "px-4 py-6 sm:px-8"}>
        {shownRows.map((row) => (
          <section key={row.id} id={`cat-${row.id}`}>
            <h3 className="mb-2 text-base font-semibold">
              {row.title}
              <span className="ml-2 text-sm font-normal text-muted">{row.list.length}</span>
            </h3>
            <ul
              className={
                category === "All"
                  ? "flex snap-x gap-2 overflow-x-auto pb-2"
                  : "grid grid-cols-3 gap-2 sm:grid-cols-4 md:grid-cols-6 xl:grid-cols-8"
              }
            >
              {row.list.map((item) => (
                <li key={`${row.id}-${item.id}`} className="snap-start">
                  <button
                    type="button"
                    onClick={() => choose(item)}
                    className="w-28 text-left sm:w-36"
                    aria-pressed={item.id === selected?.id}
                  >
                    <Poster name={item.name} poster={item.poster} active={item.id === selected?.id} />
                  </button>
                </li>
              ))}
            </ul>
          </section>
        ))}
      </div>
      </div>
    </div>
  );
}

function SeasonChip({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={
        active
          ? "h-11 shrink-0 rounded-md bg-fg px-3 text-sm font-medium text-bg"
          : "h-11 shrink-0 rounded-md bg-panel-2 px-3 text-sm text-fg"
      }
    >
      {label}
    </button>
  );
}

function Poster({ name, poster, active }: { name: string; poster?: string; active: boolean }) {
  const [failed, setFailed] = useState(false);
  const tone = CARD_TONES[name.length % CARD_TONES.length];
  return (
    <span
      className={
        active
          ? "relative flex aspect-[2/3] items-end overflow-hidden rounded-md ring-2 ring-fg"
          : "relative flex aspect-[2/3] items-end overflow-hidden rounded-md"
      }
      style={{ background: tone }}
    >
      {poster && !failed ? (
        <img
          src={`${previewAsset("/api/media")}?url=${encodeURIComponent(poster)}`}
          alt=""
          className="absolute inset-0 h-full w-full object-cover"
          onError={() => setFailed(true)}
        />
      ) : null}
      <span className="relative line-clamp-3 w-full bg-gradient-to-t from-black/80 to-transparent p-2 text-left text-xs font-semibold sm:text-sm">
        {name}
      </span>
    </span>
  );
}
