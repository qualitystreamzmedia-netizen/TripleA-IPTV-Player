import { useEffect, useMemo, useState } from "react";
import { createPortal } from "react-dom";
import { Search, Settings, Star } from "lucide-react";
import {
  currentProgram,
  demoCatalog,
  formatClock,
  formatTime,
  loadEpisodes,
  loadFavorites,
  loadM3u,
  loadSavedSource,
  loadXtream,
  loadEpg,
  nextProgram,
  programsFor,
  saveFavorites,
  saveSource,
  type Catalog,
  type Channel,
  type Series,
  type Source,
} from "@/lib/iptv";
import { PreviewPlayer } from "@/components/triplea/player";
import { TitleShelf } from "@/components/triplea/shelf";
import { CategoryEditor } from "@/components/triplea/category-editor";
import { previewAsset } from "@/lib/preview-path-prefix";
import {
  arrangeCategories,
  loadCategoryPrefs,
  playlistNames,
  saveCategoryPrefs,
  type CategoryPrefs,
  type CategorySection,
} from "@/lib/categories";

const WINDOW_MS = 3 * 60 * 60 * 1000;
const FONT_KEY = "triplea-iptv-v1-font";

function loadFontSize(): number {
  try {
    const value = Number(localStorage.getItem(FONT_KEY));
    if (Number.isFinite(value) && value >= 10 && value <= 18) return value;
  } catch {
    /* keep the default */
  }
  return 12;
}

function saveFontSize(value: number) {
  localStorage.setItem(FONT_KEY, String(value));
}

function useNow() {
  const [now, setNow] = useState<number | null>(null);
  useEffect(() => {
    const tick = () => setNow(Date.now());
    tick();
    const id = window.setInterval(tick, 30000);
    return () => window.clearInterval(id);
  }, []);
  return now;
}

export function TripleAApp() {
  const tick = useNow();
  const now = tick ?? 0;
  const [catalog, setCatalog] = useState<Catalog>(() => demoCatalog());
  const [section, setSection] = useState<"live" | "movies" | "series">("live");
  const [source, setSource] = useState<Source>({ mode: "demo" });
  const [group, setGroup] = useState("All");
  const [query, setQuery] = useState("");
  const [selectedId, setSelectedId] = useState<string>("bunny");
  const [favorites, setFavorites] = useState<string[]>([]);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [booted, setBooted] = useState(false);
  const [feature, setFeature] = useState({ url: "", title: "" });
  const [openEpisodes, setOpenEpisodes] = useState<NonNullable<Series["episodes"]>>([]);
  const [loadingSeries, setLoadingSeries] = useState("");
  const [seriesNote, setSeriesNote] = useState("");
  const [screenOpen, setScreenOpen] = useState(true);
  const [guideState, setGuideState] = useState<"sample" | "loading" | "live" | "empty">("sample");
  const [logo, setLogo] = useState("/logo.png");
  const [categoryPrefs, setCategoryPrefs] = useState(loadCategoryPrefs);
  const [categorySection, setCategorySection] = useState<CategorySection>("live");
  const [fontSize, setFontSize] = useState(12);
  const [pins, setPins] = useState<{ url: string; title: string }[]>([]);
  const channels = catalog.channels;

  function togglePin(url: string, title: string) {
    if (!url) return;
    setPins((current) => {
      const existing = current.findIndex((pin) => pin.url === url);
      if (existing >= 0) return current.filter((pin) => pin.url !== url);
      const next = [...current, { url, title }];
      return next.length > 2 ? next.slice(next.length - 2) : next;
    });
  }

  useEffect(() => {
    const saved = loadSavedSource();
    const favs = loadFavorites();
    setFavorites(favs);
    setFontSize(loadFontSize());
    setLogo(previewAsset("/logo.png"));
    setSource(saved);
    if (saved.mode === "demo") {
      setCatalog(demoCatalog());
      setBooted(true);
      return;
    }
    const run =
      saved.mode === "m3u" ? loadM3u(saved.url) : loadXtream(saved.server, saved.username, saved.password);
    run
      .then((next) => {
        setCatalog(next);
        setSelectedId(next.channels[0]?.id ?? "");
      })
      .catch(() => {
        setSource({ mode: "demo" });
        setCatalog(demoCatalog());
      })
      .finally(() => setBooted(true));
  }, []);

  useEffect(() => {
    const epgUrl = catalog.epgUrl;
    if (!epgUrl) {
      setGuideState("sample");
      return;
    }
    setGuideState("loading");
    let dead = false;
    loadEpg(epgUrl, catalog.channels, Date.now(), (channels) => {
      if (dead) return;
      setGuideState("live");
      setCatalog((current) => (current.epgUrl === epgUrl ? { ...current, channels } : current));
    })
      .then((channels) => {
        if (dead) return;
        setGuideState(channels.some((channel) => channel.guide === "epg") ? "live" : "empty");
        setCatalog((current) => (current.epgUrl === epgUrl ? { ...current, channels } : current));
      })
      .catch(() => {
        if (!dead) setGuideState("empty");
      });
    return () => {
      dead = true;
    };
  }, [catalog.epgUrl]);

  const liveCategories = useMemo(
    () => arrangeCategories(playlistNames(channels.map((channel) => channel.group)), categoryPrefs.live),
    [categoryPrefs.live, channels],
  );
  const movieCategories = useMemo(
    () => arrangeCategories(playlistNames(catalog.movies.map((item) => item.group)), categoryPrefs.movies),
    [catalog.movies, categoryPrefs.movies],
  );
  const seriesCategories = useMemo(
    () => arrangeCategories(playlistNames(catalog.series.map((item) => item.group)), categoryPrefs.series),
    [catalog.series, categoryPrefs.series],
  );
  const groups = ["All", "Favorites", ...liveCategories.map((category) => category.id)];

  useEffect(() => {
    if (group !== "All" && group !== "Favorites" && !liveCategories.some((category) => category.id === group)) {
      setGroup("All");
    }
  }, [group, liveCategories]);

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return channels.filter((channel) => {
      if (group === "Favorites" && !favorites.includes(channel.id)) return false;
      if (group !== "All" && group !== "Favorites" && channel.group !== group) return false;
      if (!q) return true;
      return channel.name.toLowerCase().includes(q) || channel.group.toLowerCase().includes(q);
    });
  }, [channels, favorites, group, query]);

  const selected = visible.find((channel) => channel.id === selectedId) ?? visible[0] ?? channels[0];
  const onNow = selected ? currentProgram(selected, now) : undefined;
  const coming = selected ? nextProgram(selected, now) : undefined;
  const windowStart = now - (now % (30 * 60 * 1000));

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      const target = event.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) return;
      if (section !== "live" || !visible.length) return;
      const index = Math.max(0, visible.findIndex((channel) => channel.id === selected?.id));
      if (event.key === "ArrowDown") {
        event.preventDefault();
        setSelectedId(visible[(index + 1) % visible.length].id);
        setScreenOpen(true);
      } else if (event.key === "ArrowUp") {
        event.preventDefault();
        setSelectedId(visible[(index - 1 + visible.length) % visible.length].id);
        setScreenOpen(true);
      } else if (event.key === "f" || event.key === "F") {
        if (selected) toggleFavorite(selected.id);
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  function stepChannel(delta: number) {
    if (!visible.length) return;
    const index = Math.max(0, visible.findIndex((channel) => channel.id === selected?.id));
    const next = (index + delta + visible.length) % visible.length;
    setSelectedId(visible[next].id);
    setScreenOpen(true);
  }

  function updateCategoryPrefs(section: CategorySection, next: CategoryPrefs) {
    setCategoryPrefs((current) => {
      const prefs = { ...current, [section]: next };
      saveCategoryPrefs(prefs);
      return prefs;
    });
  }

  function categoryTitle(id: string) {
    if (id === "All" || id === "Favorites") return id;
    return liveCategories.find((category) => category.id === id)?.label ?? id;
  }

  function toggleFavorite(id: string) {
    setFavorites((current) => {
      const next = current.includes(id) ? current.filter((item) => item !== id) : [...current, id];
      saveFavorites(next);
      return next;
    });
  }

  function applyCatalog(next: Catalog, nextSource: Source) {
    setCatalog(next);
    setSource(nextSource);
    saveSource(nextSource);
    setSection("live");
    setGroup("All");
    setQuery("");
    setSelectedId(next.channels[0]?.id ?? "");
    setFeature({ url: "", title: "" });
    setOpenEpisodes([]);
    setSettingsOpen(false);
  }

  function openSeries(item: Series) {
    setSeriesNote("");
    setFeature({ url: "", title: item.name });
    if (item.episodes) {
      setOpenEpisodes(item.episodes);
      setLoadingSeries("");
      return;
    }
    setOpenEpisodes([]);
    setLoadingSeries(item.id);
    void loadEpisodes(source, item.id)
      .then((episodes) => {
        setOpenEpisodes(episodes);
        if (episodes.length === 0) setSeriesNote("This series did not list any episodes.");
      })
      .catch((caught: unknown) => {
        setSeriesNote(caught instanceof Error ? caught.message : "Could not load episodes.");
      })
      .finally(() => setLoadingSeries(""));
  }

  const searchPlaceholder =
    section === "live" ? "Search channels" : section === "movies" ? "Search movies" : "Search series";

  return (
    <main className="flex h-full min-h-0 flex-col overflow-hidden bg-bg text-fg">
      <header className="flex items-center gap-3 border-b border-line px-3 py-2 sm:px-4">
        <div className="flex items-center gap-2">
          <img src={logo} alt="" className="h-9 w-auto" />
          <div className="leading-tight">
            <p className="text-sm font-semibold tracking-wide">TripleA</p>
            <p className="text-xs text-muted">IPTV Player</p>
          </div>
        </div>
        <p className="hidden flex-1 text-center text-sm text-muted sm:block">
          {tick ? formatClock(tick) : "Live guide"}
        </p>
        <label className="relative ml-auto hidden min-w-0 flex-1 sm:ml-0 sm:block sm:max-w-xs">
          <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted" />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder={searchPlaceholder}
            className="h-11 w-full rounded-ui border border-line bg-panel pr-3 pl-9 text-sm text-fg outline-none placeholder:text-muted focus:border-accent"
            aria-label={searchPlaceholder}
          />
        </label>
        <button
          type="button"
          className="flex size-11 items-center justify-center rounded-ui border border-line bg-panel text-fg"
          onClick={() => setSettingsOpen(true)}
          aria-label="Sources and settings"
        >
          <Settings className="size-5" />
        </button>
      </header>

      <label className="relative mx-3 mt-3 sm:hidden">
        <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted" />
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder={searchPlaceholder}
          className="h-11 w-full rounded-ui border border-line bg-panel pr-3 pl-9 text-sm outline-none placeholder:text-muted focus:border-accent"
          aria-label={searchPlaceholder}
        />
      </label>

      <div
        className={
          section === "live"
            ? "flex gap-1 border-b border-line px-3 py-2 sm:hidden"
            : "flex gap-1 border-b border-line px-3 py-2"
        }
        role="tablist"
        aria-label="Library"
      >
        {(
          [
            ["live", "Live"],
            ["movies", "Movies"],
            ["series", "Series"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            role="tab"
            aria-selected={section === id}
            onClick={() => {
              setSection(id);
              setGroup("All");
            }}
            className={
              section === id
                ? "h-11 flex-1 rounded-ui bg-accent text-sm font-medium text-fg sm:flex-none sm:px-4"
                : "h-11 flex-1 rounded-ui text-sm text-muted sm:flex-none sm:px-4"
            }
          >
            {label}
          </button>
        ))}
      </div>

      {section === "live" ? (
        <div className="grid min-h-0 flex-1 grid-cols-1 grid-rows-[auto_auto_minmax(0,1fr)] sm:grid-cols-[8rem_minmax(10.5rem,13rem)_minmax(0,1fr)] sm:grid-rows-[auto_minmax(0,1fr)]">
          <div className="hidden items-center gap-1 border-b border-line px-2 py-1.5 sm:col-span-2 sm:row-start-1 sm:flex" role="tablist" aria-label="Library">
            {(
              [
                ["live", "Live"],
                ["movies", "Movies"],
                ["series", "Series"],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                role="tab"
                aria-selected={section === id}
                onClick={() => {
                  setSection(id);
                  setGroup("All");
                }}
                className={
                  section === id
                    ? "h-9 rounded-ui bg-accent px-3 text-sm font-medium text-fg"
                    : "h-9 rounded-ui px-3 text-sm text-muted"
                }
              >
                {label}
              </button>
            ))}
          </div>
          <nav className="hidden min-h-0 flex-col gap-1 overflow-y-auto border-r border-line p-2 sm:col-start-1 sm:row-start-2 sm:flex" aria-label="Groups">
            {groups.map((name) => (
              <button
                key={name}
                type="button"
                onClick={() => setGroup(name)}
                className={
                  name === group
                    ? "rounded-ui bg-accent px-3 py-2 text-left text-sm font-medium text-fg"
                    : "rounded-ui px-3 py-2 text-left text-sm text-muted hover:bg-panel hover:text-fg"
                }
              >
                {categoryTitle(name)}
                {name === "Favorites" ? ` (${favorites.length})` : ""}
              </button>
            ))}
          </nav>

          <div className="flex gap-2 overflow-x-auto px-3 py-2 sm:hidden">
            {groups.map((name) => (
              <button
                key={name}
                type="button"
                onClick={() => setGroup(name)}
                className={
                  name === group
                    ? "shrink-0 rounded-full bg-accent px-3 py-2 text-sm text-fg"
                    : "shrink-0 rounded-full bg-panel px-3 py-2 text-sm text-muted"
                }
              >
                {categoryTitle(name)}
              </button>
            ))}
          </div>

          <div className="flex min-h-0 flex-col sm:col-start-3 sm:row-span-2 sm:row-start-1 sm:border-l sm:border-line">
          <section className="border-b border-line p-2 sm:shrink-0">
            {selected && screenOpen ? (
              <PreviewPlayer
                url={selected.url}
                title={selected.name}
                onPrevious={() => stepChannel(-1)}
                onNext={() => stepChannel(1)}
                onClose={() => setScreenOpen(false)}
                onPin={() => togglePin(selected.url, selected.name)}
                pinned={pins.some((pin) => pin.url === selected.url)}
              />
            ) : selected ? (
              <button
                type="button"
                className="flex h-11 items-center rounded-ui bg-panel px-4 text-sm font-medium"
                onClick={() => setScreenOpen(true)}
              >
                Open screen
              </button>
            ) : null}
            <div className="mt-1.5 min-w-0">
              <p className="text-[10px] tracking-wide text-accent uppercase">
                {source.mode === "demo" ? "Demo library" : source.mode === "m3u" ? "M3U playlist" : "Xtream"}
              </p>
              <h1 className="truncate text-sm font-semibold">{onNow?.title ?? selected?.name ?? "TripleA"}</h1>
              <p className="text-xs text-muted">
                {selected ? `${selected.number}  ${selected.name}` : "No channel"}
                {onNow ? `  ·  ${formatTime(onNow.start)} – ${formatTime(onNow.end)}` : ""}
              </p>
              {onNow?.description ? (
                <p className="mt-1 text-[10px] leading-snug text-muted">{onNow.description}</p>
              ) : null}
              {coming ? (
                <p className="mt-1 text-xs">
                  <span className="text-muted">Next </span>
                  {coming.title}
                  <span className="text-muted"> · {formatTime(coming.start)}</span>
                </p>
              ) : null}
            </div>
          </section>

          <section className="hidden min-h-36 flex-1 overflow-auto sm:block">
            <Guide
              channels={visible}
              now={now}
              windowStart={windowStart}
              guideState={guideState}
              fontSize={fontSize}
              selectedId={selected?.id}
              onSelect={(id) => {
                setSelectedId(id);
                setScreenOpen(true);
              }}
            />
          </section>
          </div>

          <section className="min-h-0 overflow-y-auto border-line sm:col-start-2 sm:row-start-2 sm:border-r" aria-label="Channels">
            {visible.length === 0 ? (
              <p className="p-4 text-sm text-muted">{booted ? "No channels in this group." : "Loading channels…"}</p>
            ) : (
              <ul>
                {visible.map((channel) => {
                  const active = channel.id === selected?.id;
                  const program = currentProgram(channel, now);
                  return (
                    <li
                      key={channel.id}
                      className={active ? "flex items-stretch bg-accent text-fg" : "flex items-stretch hover:bg-panel"}
                    >
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedId(channel.id);
                          setScreenOpen(true);
                        }}
                        className="flex min-w-0 flex-1 items-center gap-2 px-2 py-1.5 text-left"
                      >
                        <span className="w-7 shrink-0 text-muted tabular-nums" style={{ fontSize: Math.max(10, fontSize - 1) }}>
                          {channel.number}
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className="block truncate font-medium" style={{ fontSize }}>
                            {channel.name}
                          </span>
                          <span className="block truncate text-muted" style={{ fontSize: Math.max(10, fontSize - 2) }}>
                            {program?.title ?? "On air"}
                          </span>
                        </span>
                      </button>
                      <button
                        type="button"
                        aria-pressed={favorites.includes(channel.id)}
                        aria-label={favorites.includes(channel.id) ? "Remove favorite" : "Add favorite"}
                        className="flex size-8 shrink-0 items-center justify-center"
                        onClick={() => toggleFavorite(channel.id)}
                      >
                        <Star
                          className={favorites.includes(channel.id) ? "size-4 fill-fg text-fg" : "size-4 text-muted"}
                        />
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
          </section>
        </div>
      ) : (
        <TitleShelf
          key={section}
          kind={section}
          items={section === "movies" ? catalog.movies : catalog.series}
          categories={section === "movies" ? movieCategories : seriesCategories}
          query={query}
          favorites={favorites}
          episodes={openEpisodes}
          loadingId={loadingSeries}
          note={seriesNote}
          playingUrl={feature.url}
          playingTitle={feature.title}
          onToggleFavorite={toggleFavorite}
          onPlay={(url, title) => setFeature({ url, title })}
          onOpen={openSeries}
          onPin={togglePin}
          pinnedUrls={pins.map((pin) => pin.url)}
        />
      )}

      {typeof document === "undefined"
        ? null
        : createPortal(
            pins.map((pin, index) => (
              <PreviewPlayer
                key={pin.url}
                url={pin.url}
                title={pin.title}
                floatIndex={index}
                onClose={() => setPins((current) => current.filter((item) => item.url !== pin.url))}
              />
            )),
            document.body,
          )}

      {settingsOpen ? (
        <SourceDialog
          source={source}
          catalog={catalog}
          categorySection={categorySection}
          categoryPrefs={categoryPrefs[categorySection]}
          fontSize={fontSize}
          onFontSize={(next) => {
            setFontSize(next);
            saveFontSize(next);
          }}
          onCategorySection={setCategorySection}
          onCategoryPrefs={(next) => updateCategoryPrefs(categorySection, next)}
          onClose={() => setSettingsOpen(false)}
          onApply={applyCatalog}
        />
      ) : null}
    </main>
  );
}

function Guide({
  channels,
  now,
  windowStart,
  guideState,
  fontSize,
  selectedId,
  onSelect,
}: {
  channels: Channel[];
  now: number;
  windowStart: number;
  guideState: "sample" | "loading" | "live" | "empty";
  fontSize: number;
  selectedId?: string;
  onSelect: (id: string) => void;
}) {
  const ticks = [0, 1, 2].map((hour) => windowStart + hour * 60 * 60 * 1000);
  const clock = now > 0 ? now : 0;
  const title =
    guideState === "live" ? "Guide" : guideState === "loading" ? "Loading guide" : guideState === "empty" ? "No listing" : "Sample guide";
  const nowLeft = clock > 0 ? ((clock - windowStart) / WINDOW_MS) * 100 : -1;
  return (
    <div className="min-w-[34rem]">
      <div className="sticky top-0 z-20 grid grid-cols-[6.5rem_minmax(0,1fr)] border-b border-line bg-panel text-[10px] text-muted">
        <span className="sticky left-0 bg-panel px-2 py-1.5">{title}</span>
        <div className="relative h-6">
          {ticks.map((mark) => (
            <span key={mark} className="absolute top-1 whitespace-nowrap" style={{ left: `${((mark - windowStart) / WINDOW_MS) * 100}%` }}>
              {formatTime(mark)}
            </span>
          ))}
        </div>
      </div>
      <ul>
        {channels.map((channel) => (
          <li key={channel.id} className="grid grid-cols-[6.5rem_minmax(0,1fr)] border-b border-line">
            <button
              type="button"
              className={
                channel.id === selectedId
                  ? "sticky left-0 truncate bg-panel px-2 py-1 text-left font-medium text-fg"
                  : "sticky left-0 truncate bg-bg px-2 py-1 text-left text-muted"
              }
              style={{ fontSize }}
              onClick={() => onSelect(channel.id)}
            >
              {channel.name}
            </button>
            <div className="relative h-8">
              {(() => {
                const listed = programsFor(channel, clock);
                const blocks = listed.filter(
                  (program) => program.end > windowStart && program.start < windowStart + WINDOW_MS,
                );
                const nearest =
                  blocks.length > 0
                    ? null
                    : (listed.find((program) => program.end > clock) ?? listed[listed.length - 1]);
                if (!nearest && blocks.length === 0) {
                  return (
                    <span className="absolute inset-y-1 right-1 left-1 flex items-center rounded-md bg-panel-2 px-1.5 text-[10px] text-muted">
                      No listing
                    </span>
                  );
                }
                const shown = blocks.length > 0 ? blocks : nearest ? [nearest] : [];
                return shown.map((program) => {
                  const start = Math.max(program.start, windowStart);
                  const end = Math.min(program.end, windowStart + WINDOW_MS);
                  const left = blocks.length > 0 ? ((start - windowStart) / WINDOW_MS) * 100 : 0;
                  const width = blocks.length > 0 ? Math.max(0, ((end - start) / WINDOW_MS) * 100) : 100;
                  const live = program.start <= clock && clock < program.end;
                  return (
                    <button
                      key={program.id}
                      type="button"
                      onClick={() => onSelect(channel.id)}
                      className={
                        live
                          ? "absolute top-1 bottom-1 flex items-center overflow-hidden rounded-md bg-accent px-1.5 text-left text-[10px] leading-none text-fg"
                          : "absolute top-1 bottom-1 flex items-center overflow-hidden rounded-md bg-panel-2 px-1.5 text-left text-[10px] leading-none text-muted"
                      }
                      style={{ left: `${left}%`, width: `calc(${width}% - 3px)` }}
                      title={`${program.title}${program.description ? ` — ${program.description}` : ""}`}
                    >
                      <span className="truncate">{formatTime(program.start)} {program.title}</span>
                    </button>
                  );
                });
              })()}
              {nowLeft >= 0 && nowLeft <= 100 ? (
                <span className="pointer-events-none absolute top-0 bottom-0 z-10 w-px bg-live" style={{ left: `${nowLeft}%` }} aria-hidden="true" />
              ) : null}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

function SourceDialog({
  source,
  catalog,
  categorySection,
  categoryPrefs,
  fontSize,
  onFontSize,
  onCategorySection,
  onCategoryPrefs,
  onClose,
  onApply,
}: {
  source: Source;
  catalog: Catalog;
  categorySection: CategorySection;
  categoryPrefs: CategoryPrefs;
  fontSize: number;
  onFontSize: (size: number) => void;
  onCategorySection: (section: CategorySection) => void;
  onCategoryPrefs: (prefs: CategoryPrefs) => void;
  onClose: () => void;
  onApply: (catalog: Catalog, source: Source) => void;
}) {
  const [tab, setTab] = useState<Source["mode"]>(source.mode);
  const [m3u, setM3u] = useState(source.mode === "m3u" ? source.url : "");
  const [server, setServer] = useState(source.mode === "xtream" ? source.server : "");
  const [username, setUsername] = useState(source.mode === "xtream" ? source.username : "");
  const [password, setPassword] = useState(source.mode === "xtream" ? source.password : "");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function connect() {
    setError("");
    setBusy(true);
    try {
      if (tab === "demo") {
        onApply(demoCatalog(), { mode: "demo" });
        return;
      }
      if (tab === "m3u") {
        onApply(await loadM3u(m3u.trim()), { mode: "m3u", url: m3u.trim() });
        return;
      }
      onApply(await loadXtream(server.trim(), username.trim(), password), {
        mode: "xtream",
        server: server.trim(),
        username: username.trim(),
        password,
      });
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Could not load that source.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center p-3 sm:items-center" role="dialog" aria-modal="true" aria-labelledby="source-title">
      <button type="button" className="absolute inset-0 bg-bg/80" aria-label="Close settings" onClick={onClose} />
      <div className="relative z-10 max-h-[85vh] w-full max-w-lg overflow-y-auto rounded-ui border border-line bg-panel p-4 shadow-2xl">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h2 id="source-title" className="text-lg font-semibold">Sources</h2>
            <p className="mt-1 text-sm text-muted">
              TripleA plays your own Xtream login or M3U link. The demo library is public sample video, not a channel package.
            </p>
          </div>
          <button type="button" className="rounded-ui px-3 py-2 text-sm text-muted hover:text-fg" onClick={onClose}>
            Close
          </button>
        </div>
        <div className="mt-4 grid grid-cols-3 gap-2" role="tablist">
          {(
            [
              ["demo", "Demo"],
              ["xtream", "Xtream"],
              ["m3u", "M3U"],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              role="tab"
              aria-selected={tab === id}
              onClick={() => setTab(id)}
              className={
                tab === id
                  ? "h-11 rounded-ui bg-accent text-sm font-medium text-fg"
                  : "h-11 rounded-ui bg-panel-2 text-sm text-muted"
              }
            >
              {label}
            </button>
          ))}
        </div>
        {tab === "xtream" ? (
          <div className="mt-4 grid gap-3">
            <Field label="Server URL" value={server} onChange={setServer} placeholder="http://example.com:8080" />
            <Field label="Username" value={username} onChange={setUsername} placeholder="username" />
            <Field label="Password" value={password} onChange={setPassword} placeholder="password" secret />
          </div>
        ) : null}
        {tab === "m3u" ? (
          <div className="mt-4">
            <Field label="Playlist URL" value={m3u} onChange={setM3u} placeholder="https://example.com/list.m3u" />
          </div>
        ) : null}
        {tab === "demo" ? (
          <p className="mt-4 text-sm text-muted">
            Open movies and test patterns you can play immediately. Arrow keys change channel. F favorites the selected one.
          </p>
        ) : null}
        {error ? <p className="mt-3 text-sm text-live">{error}</p> : null}
        <button
          type="button"
          disabled={busy}
          onClick={() => void connect()}
          className="mt-4 h-11 w-full rounded-ui bg-accent text-sm font-semibold text-fg disabled:opacity-60"
        >
          {busy ? "Connecting…" : tab === "demo" ? "Use demo library" : "Connect"}
        </button>
        <label className="mt-4 grid gap-1 text-sm">
          <span className="flex items-center justify-between text-muted">
            Channel list size
            <span className="text-fg tabular-nums">{fontSize}px</span>
          </span>
          <input
            type="range"
            min={10}
            max={18}
            step={1}
            value={fontSize}
            aria-label="Channel list font size"
            className="volume-bar w-full"
            onChange={(event) => onFontSize(Number(event.target.value))}
          />
        </label>
        <CategoryEditor
          section={categorySection}
          onSection={onCategorySection}
          names={
            categorySection === "live"
              ? playlistNames(catalog.channels.map((channel) => channel.group))
              : categorySection === "movies"
                ? playlistNames(catalog.movies.map((item) => item.group))
                : playlistNames(catalog.series.map((item) => item.group))
          }
          prefs={categoryPrefs}
          onChange={onCategoryPrefs}
        />
      </div>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  placeholder,
  secret,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder: string;
  secret?: boolean;
}) {
  return (
    <label className="grid gap-1 text-sm">
      <span className="text-muted">{label}</span>
      <input
        type={secret ? "password" : "text"}
        value={value}
        placeholder={placeholder}
        onChange={(event) => onChange(event.target.value)}
        className="h-11 rounded-ui border border-line bg-bg px-3 text-fg outline-none placeholder:text-muted focus:border-accent"
        autoComplete="off"
      />
    </label>
  );
}
