import { previewAsset } from "@/lib/preview-path-prefix";

export type Program = {
  id: string;
  title: string;
  start: number;
  end: number;
  description: string;
};

export type Channel = {
  id: string;
  name: string;
  group: string;
  number: number;
  url: string;
  programs: Program[];
  epgId?: string;
  guide?: "epg" | "sample" | "none";
};

export type Movie = {
  id: string;
  name: string;
  group: string;
  plot: string;
  poster?: string;
  url: string;
};

export type Episode = {
  id: string;
  title: string;
  season: number;
  number: number;
  url: string;
};

export type Series = {
  id: string;
  name: string;
  group: string;
  plot: string;
  poster?: string;
  episodes?: Episode[];
};

export type Catalog = {
  channels: Channel[];
  movies: Movie[];
  series: Series[];
  epgUrl?: string;
};

export type Source =
  | { mode: "demo" }
  | { mode: "m3u"; url: string }
  | { mode: "xtream"; server: string; username: string; password: string };

const BLOCK = 30 * 60 * 1000;
const STORAGE_KEY = "triplea-iptv-v1";

const SHOWS: Record<string, string[]> = {
  Film: ["Open Reel", "Night Drive", "Second Feature", "Short Subject", "Late Matinee", "Studio Loop"],
  Sport: ["Match Window", "Training Tape", "Highlight Reel", "Court Side", "Lap Times", "Locker Room"],
  News: ["Desk Brief", "Field Note", "Hourly Update", "City Wire", "Weather Slot", "Late Bulletin"],
  Science: ["Orbit Watch", "Lab Hour", "Signal Check", "Deep Field", "Test Pattern", "Mission Loop"],
  Music: ["Session", "Live Room", "Night Shift", "Acoustic Set", "Backline", "Encore"],
  General: ["On Air", "Continuity", "Open Slot", "Station ID", "Feature", "Replay"],
};

function hash(value: string): number {
  let n = 0;
  for (let i = 0; i < value.length; i++) n = (n * 33 + value.charCodeAt(i)) >>> 0;
  return n;
}

export function guidePrograms(channelId: string, group: string, now = Date.now()): Program[] {
  const titles = SHOWS[group] ?? SHOWS.General;
  const origin = now - (now % BLOCK) - BLOCK;
  const salt = hash(channelId);
  const programs: Program[] = [];
  for (let i = 0; i < 12; i++) {
    const start = origin + i * BLOCK;
    const title = titles[(i + salt) % titles.length];
    programs.push({
      id: `${channelId}-${start}`,
      title,
      start,
      end: start + BLOCK,
      description:
        group === "General"
          ? "No programme guide came with this playlist. This slot is a local placeholder."
          : `${title}. Sample guide so the timeline stays readable. Your provider's EPG replaces this when it sends one.`,
    });
  }
  return programs;
}

const DEMO_SEED: Array<Omit<Channel, "programs" | "number">> = [
  {
    id: "bunny",
    name: "Big Buck Bunny",
    group: "Film",
    url: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
  },
  {
    id: "tears",
    name: "Tears of Steel",
    group: "Film",
    url: "https://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8",
  },
  {
    id: "dark",
    name: "Dark Truths",
    group: "Film",
    url: "https://storage.googleapis.com/shaka-demo-assets/bbb-dark-truths-hls/hls.m3u8",
  },
  {
    id: "angel",
    name: "Angel One",
    group: "Music",
    url: "https://storage.googleapis.com/shaka-demo-assets/angel-one-hls/hls.m3u8",
  },
  {
    id: "bipbop",
    name: "Bipbop",
    group: "News",
    url: "https://devstreaming-cdn.apple.com/videos/streaming/examples/img_bipbop_adv_example_fmp4/master.m3u8",
  },
  {
    id: "bipbop-wide",
    name: "Bipbop Wide",
    group: "News",
    url: "https://devstreaming-cdn.apple.com/videos/streaming/examples/bipbop_16x9/bipbop_16x9_variant.m3u8",
  },
  {
    id: "pattern",
    name: "Test Pattern",
    group: "Science",
    url: "https://test-streams.mux.dev/test_001/stream.m3u8",
  },
  {
    id: "nasa",
    name: "NASA TV",
    group: "Science",
    url: "https://ntv1.akamaized.net/hls/live/2014075/NASA-NTV1-HLS/master.m3u8",
  },
  {
    id: "shift",
    name: "Timing Reel",
    group: "Sport",
    url: "https://test-streams.mux.dev/pts_shift/master.m3u8",
  },
  {
    id: "break",
    name: "Break Sample",
    group: "Sport",
    url: "https://test-streams.mux.dev/dai-discontinuity-deltatre/manifest.m3u8",
  },
];

export function demoChannels(now = Date.now()): Channel[] {
  return DEMO_SEED.map((channel, index) => ({
    ...channel,
    number: index + 1,
    programs: guidePrograms(channel.id, channel.group, now),
    guide: "sample",
  }));
}

export function demoCatalog(now = Date.now()): Catalog {
  const channels = demoChannels(now);
  const films = channels.filter((channel) => channel.group === "Film");
  const reels = channels.filter((channel) => channel.group === "Science" || channel.group === "Sport");
  const movies: Movie[] = channels.map((channel) => ({
    id: `movie-${channel.id}`,
    name: channel.name,
    group: channel.group,
    plot: "Public sample you can play in the browser.",
    url: channel.url,
  }));
  const series: Series[] = [
    {
      id: "series-shorts",
      name: "Open Shorts",
      group: "Film",
      plot: "Three public short films, listed as season 1.",
      episodes: films.map((channel, index) => ({
        id: `ep-${channel.id}`,
        title: channel.name,
        season: 1,
        number: index + 1,
        url: channel.url,
      })),
    },
    {
      id: "series-lab",
      name: "Lab Reels",
      group: "Science",
      plot: "Test patterns and timing reels.",
      episodes: reels.map((channel, index) => ({
        id: `ep-${channel.id}`,
        title: channel.name,
        season: 1,
        number: index + 1,
        url: channel.url,
      })),
    },
  ];
  return { channels, movies, series };
}

export function programsFor(channel: Channel, now: number): Program[] {
  if (channel.guide !== "sample") return channel.programs;
  const clock = now || Date.now();
  const covering = channel.programs.some((program) => program.start <= clock && clock < program.end);
  if (covering) return channel.programs;
  return guidePrograms(channel.id, channel.group, clock);
}

export function currentProgram(channel: Channel, now: number): Program | undefined {
  return programsFor(channel, now).find((program) => program.start <= now && now < program.end);
}

export function nextProgram(channel: Channel, now: number): Program | undefined {
  return programsFor(channel, now).find((program) => program.start > now);
}

function attr(line: string, name: string): string {
  const match = line.match(new RegExp(`${name}\\s*=\\s*(?:"([^"]*)"|'([^']*)')`, "i"));
  return (match?.[1] ?? match?.[2] ?? "").trim();
}

export function parseM3u(text: string, now = Date.now()): Channel[] {
  const lines = text.split(/\r?\n/);
  const channels: Channel[] = [];
  let pending: { name: string; group: string; epgId?: string } | null = null;
  for (const raw of lines) {
    const line = raw.trim();
    if (!line) continue;
    if (line.startsWith("#EXTINF")) {
      const comma = line.lastIndexOf(",");
      const name = (comma >= 0 ? line.slice(comma + 1) : "Channel").trim() || "Channel";
      const group = attr(line, "group-title") || "General";
      const epgId = attr(line, "tvg-id") || undefined;
      pending = { name, group, epgId };
      continue;
    }
    if (line.startsWith("#")) continue;
    if (!/^https?:\/\//i.test(line)) {
      pending = null;
      continue;
    }
    const meta = pending ?? { name: `Channel ${channels.length + 1}`, group: "General" };
    const id = `m3u-${channels.length + 1}`;
    channels.push({
      id,
      name: meta.name,
      group: meta.group,
      number: channels.length + 1,
      url: line,
      epgId: meta.epgId,
      guide: "none",
      programs: [],
    });
    pending = null;
  }
  return channels;
}

export function playlistEpgUrl(text: string): string {
  const header = text.split(/\r?\n/).find((line) => line.startsWith("#EXTM3U")) ?? "";
  return attr(header, "url-tvg") || attr(header, "x-tvg-url") || attr(header, "tvg-url");
}

type XtreamCategory = { category_id?: string | number; category_name?: string };
type XtreamStream = {
  stream_id?: number;
  series_id?: number;
  name?: string;
  category_id?: string | number | Array<string | number>;
  category_name?: string;
  stream_icon?: string;
  epg_channel_id?: string;
  cover?: string;
  plot?: string;
  container_extension?: string;
};

function asList<T>(value: unknown): T[] {
  if (Array.isArray(value)) return value as T[];
  if (value && typeof value === "object") return Object.values(value) as T[];
  return [];
}

function categoryIdOf(row: XtreamStream): string {
  const raw = row.category_id;
  if (Array.isArray(raw)) return raw.length ? String(raw[0]) : "";
  if (raw == null) return "";
  return String(raw);
}

function categoryNames(categories: unknown): Map<string, string> {
  const names = new Map<string, string>();
  for (const category of asList<XtreamCategory>(categories)) {
    if (category?.category_id != null) {
      names.set(String(category.category_id), category.category_name?.trim() || "General");
    }
  }
  return names;
}

function groupName(row: XtreamStream, names: Map<string, string>, fallback: string): string {
  const id = categoryIdOf(row);
  return row.category_name?.trim() || names.get(id) || (id ? `Category ${id}` : fallback);
}

function posterOf(row: XtreamStream): string | undefined {
  const poster = row.stream_icon || row.cover;
  return poster && /^https?:\/\//i.test(poster) ? poster : undefined;
}

export async function loadXtream(
  server: string,
  username: string,
  password: string,
  now = Date.now(),
): Promise<Catalog> {
  const base = serverBase(server);
  const auth = `username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`;
  const info = (await readJson(`${base}/player_api.php?${auth}`)) as {
    user_info?: { auth?: number; status?: string };
  };
  if (info?.user_info && info.user_info.auth === 0) {
    throw new Error("That username or password was rejected.");
  }
  const [liveCategories, liveStreams, vodCategories, vodStreams, seriesCategories, seriesList] =
    await Promise.all([
      readJson(`${base}/player_api.php?${auth}&action=get_live_categories`).catch(() => []),
      readJson(`${base}/player_api.php?${auth}&action=get_live_streams`),
      readJson(`${base}/player_api.php?${auth}&action=get_vod_categories`).catch(() => []),
      readJson(`${base}/player_api.php?${auth}&action=get_vod_streams`).catch(() => []),
      readJson(`${base}/player_api.php?${auth}&action=get_series_categories`).catch(() => []),
      readJson(`${base}/player_api.php?${auth}&action=get_series`).catch(() => []),
    ]);
  const liveRows = asList<XtreamStream>(liveStreams);
  if (!liveRows.length) throw new Error("This server did not return a channel list.");
  const liveNames = categoryNames(liveCategories);
  const user = encodeURIComponent(username);
  const pass = encodeURIComponent(password);
  const channels = takeByCategory(liveRows, liveNames, "General", 120, (stream, index, group) => {
    const id = String(stream.stream_id ?? index + 1);
    return {
      id: `xt-${id}`,
      name: stream.name?.trim() || `Channel ${index + 1}`,
      group,
      number: index + 1,
      url: `${base}/live/${user}/${pass}/${id}.m3u8`,
      epgId: stream.epg_channel_id?.trim() || id,
      guide: "none" as const,
      programs: [],
    };
  });
  const movieNames = categoryNames(vodCategories);
  const movies = takeByCategory(asList<XtreamStream>(vodStreams), movieNames, "Movies", 80, (stream, index, group) => {
    const id = String(stream.stream_id ?? index + 1);
    const ext = (stream.container_extension || "mp4").replace(/^\./, "");
    return {
      id: `xtm-${id}`,
      name: stream.name?.trim() || `Movie ${index + 1}`,
      group,
      plot: stream.plot?.trim() || "",
      poster: posterOf(stream),
      url: `${base}/movie/${user}/${pass}/${id}.${ext}`,
    };
  });
  const seriesNames = categoryNames(seriesCategories);
  const series = takeByCategory(asList<XtreamStream>(seriesList), seriesNames, "Series", 80, (stream, index, group) => {
    const id = String(stream.series_id ?? stream.stream_id ?? index + 1);
    return {
      id: `xts-${id}`,
      name: stream.name?.trim() || `Series ${index + 1}`,
      group,
      plot: stream.plot?.trim() || "",
      poster: posterOf(stream),
    };
  });
  return { channels, movies, series, epgUrl: `${base}/xmltv.php?${auth}` };
}

function takeByCategory<T>(
  rows: XtreamStream[],
  names: Map<string, string>,
  fallback: string,
  limit: number,
  make: (row: XtreamStream, index: number, group: string) => T,
): T[] {
  const counts = new Map<string, number>();
  const out: T[] = [];
  rows.forEach((row, index) => {
    if (!row || typeof row !== "object") return;
    const group = groupName(row, names, fallback);
    const used = counts.get(group) ?? 0;
    if (used >= limit) return;
    counts.set(group, used + 1);
    out.push(make(row, index, group));
  });
  return out;
}

export async function loadEpisodes(source: Source, seriesId: string): Promise<Episode[]> {
  if (source.mode !== "xtream") return [];
  const id = seriesId.replace(/^xts-/, "");
  const base = serverBase(source.server);
  const auth = `username=${encodeURIComponent(source.username)}&password=${encodeURIComponent(source.password)}`;
  const info = (await readJson(
    `${base}/player_api.php?${auth}&action=get_series_info&series_id=${encodeURIComponent(id)}`,
  )) as { episodes?: unknown };
  const buckets: unknown[] = [];
  if (Array.isArray(info.episodes)) buckets.push(...info.episodes);
  else if (info.episodes && typeof info.episodes === "object") {
    for (const value of Object.values(info.episodes)) {
      if (Array.isArray(value)) buckets.push(...value);
    }
  }
  const user = encodeURIComponent(source.username);
  const pass = encodeURIComponent(source.password);
  const episodes: Episode[] = [];
  for (const item of buckets) {
    if (!item || typeof item !== "object") continue;
    const row = item as Record<string, unknown>;
    const episodeId = String(row.id ?? "");
    if (!episodeId) continue;
    const ext = String(row.container_extension || "mp4").replace(/^\./, "");
    episodes.push({
      id: episodeId,
      title: String(row.title || `Episode ${row.episode_num ?? episodes.length + 1}`).trim(),
      season: Number(row.season ?? 1) || 1,
      number: Number(row.episode_num ?? episodes.length + 1) || episodes.length + 1,
      url: `${base}/series/${user}/${pass}/${episodeId}.${ext}`,
    });
  }
  episodes.sort((a, b) => a.season - b.season || a.number - b.number);
  return episodes;
}
function serverBase(server: string): string {
  const trimmed = server.trim().replace(/\/+$/, "");
  if (!/^https?:\/\//i.test(trimmed)) return `http://${trimmed}`;
  return trimmed;
}

async function readJson(url: string): Promise<unknown> {
  const response = await fetch(`${previewAsset("/api/media")}?url=${encodeURIComponent(url)}`);
  if (!response.ok) throw new Error(`The server answered ${response.status}.`);
  return response.json();
}

export async function loadM3u(url: string, now = Date.now()): Promise<Catalog> {
  const response = await fetch(`${previewAsset("/api/media")}?url=${encodeURIComponent(url)}`);
  if (!response.ok) throw new Error(`The playlist answered ${response.status}.`);
  const text = await response.text();
  const channels = parseM3u(text, now);
  if (channels.length === 0) throw new Error("That playlist did not contain any http streams.");
  const epgUrl = playlistEpgUrl(text);
  return { channels, movies: [], series: [], epgUrl: epgUrl || undefined };
}

function xmltvTime(value: string): number {
  const match = value.match(/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})\s*([+-]\d{4})?/);
  if (!match) return Number.NaN;
  const [, year, month, day, hour, minute, second, zone] = match;
  const utc = Date.UTC(Number(year), Number(month) - 1, Number(day), Number(hour), Number(minute), Number(second));
  if (!zone) return utc;
  const sign = zone.startsWith("-") ? -1 : 1;
  const offset = sign * (Number(zone.slice(1, 3)) * 60 + Number(zone.slice(3, 5))) * 60 * 1000;
  return utc - offset;
}

function xmlText(body: string, tag: string): string {
  const match = body.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)</${tag}>`, "i"));
  return (match?.[1] ?? "")
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/<[^>]+>/g, "")
    .replaceAll("&" + "amp;", "&")
    .replaceAll("&" + "lt;", "<")
    .replaceAll("&" + "gt;", ">")
    .replaceAll("&" + "quot;", '"')
    .replaceAll("&" + "apos;", "'")
    .trim();
}

function remember(map: Map<string, Program[]>, key: string, program: Program) {
  const id = key.trim();
  if (!id) return;
  const list = map.get(id) ?? map.get(id.toLowerCase()) ?? [];
  list.push(program);
  map.set(id, list);
  map.set(id.toLowerCase(), list);
}

function normName(value: string): string {
  return value
    .toLowerCase()
    .replace(/\b(hd|fhd|sd|uhd|4k|hevc|raw)\b/g, "")
    .replace(/[^a-z0-9]+/g, "");
}

function listingsFor(channel: Channel, byChannel: Map<string, Program[]>, names: Map<string, string>): Program[] | undefined {
  const keys = [channel.epgId, channel.id.replace(/^xt-/, ""), channel.name, normName(channel.name)];
  for (const key of keys) {
    if (!key) continue;
    const found = byChannel.get(key) ?? byChannel.get(key.toLowerCase()) ?? byChannel.get(normName(key));
    if (found?.length) return found;
  }
  const named = names.get(channel.name.trim().toLowerCase()) ?? names.get(normName(channel.name));
  if (!named) return undefined;
  return byChannel.get(named) ?? byChannel.get(named.toLowerCase());
}

export function applyXmltv(channels: Channel[], xml: string, now = Date.now()): Channel[] {
  const from = now - 60 * 60 * 1000;
  const to = now + 8 * 60 * 60 * 1000;
  const byChannel = new Map<string, Program[]>();
  const names = new Map<string, string>();
  const channelRe = /<channel\b([^>]*)>([\s\S]*?)<\/channel>/gi;
  let channelMatch: RegExpExecArray | null;
  while ((channelMatch = channelRe.exec(xml))) {
    const id = attr(channelMatch[1], "id");
    const display = xmlText(channelMatch[2], "display-name");
    if (id && display) {
      names.set(display.toLowerCase(), id);
      names.set(normName(display), id);
    }
  }
  const programmeRe = /<programme\b([^>]*)>([\s\S]*?)<\/programme>/gi;
  let programmeMatch: RegExpExecArray | null;
  let count = 0;
  while ((programmeMatch = programmeRe.exec(xml)) && count < 40000) {
    count += 1;
    const channel = attr(programmeMatch[1], "channel");
    const start = xmltvTime(attr(programmeMatch[1], "start"));
    const end = xmltvTime(attr(programmeMatch[1], "stop"));
    if (!channel || !Number.isFinite(start) || !Number.isFinite(end) || end < from || start > to) continue;
    remember(byChannel, channel, {
      id: `${channel}-${start}`,
      title: xmlText(programmeMatch[2], "title") || "Programme",
      start,
      end,
      description: xmlText(programmeMatch[2], "desc"),
    });
  }
  if (byChannel.size === 0) return channels;
  return channels.map((channel) => {
    const programs = listingsFor(channel, byChannel, names);
    if (!programs?.length) return channel;
    const unique = [...programs]
      .sort((a, b) => a.start - b.start)
      .filter((program, index, list) => index === 0 || program.start !== list[index - 1].start);
    return { ...channel, programs: unique, guide: "epg" };
  });
}

async function readPayload(url: string): Promise<string> {
  const response = await fetch(`${previewAsset("/api/media")}?url=${encodeURIComponent(url)}`);
  if (!response.ok) throw new Error(`The guide answered ${response.status}.`);
  const bytes = new Uint8Array(await response.arrayBuffer());
  if (bytes[0] === 0x1f && bytes[1] === 0x8b && typeof DecompressionStream !== "undefined") {
    const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream("gzip"));
    return new Response(stream).text();
  }
  return new TextDecoder().decode(bytes);
}

function decodeField(value: unknown): string {
  const text = String(value ?? "").trim();
  if (!text) return "";
  if (text.length % 4 === 0 && /^[A-Za-z0-9+/]+={0,2}$/.test(text)) {
    try {
      const binary = atob(text);
      const bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0));
      const decoded = new TextDecoder().decode(bytes).trim();
      const readable = [...decoded].filter((char) => char >= " " && char !== "\u007f").length;
      if (decoded && readable / decoded.length > 0.85) return decoded;
    } catch {
      /* already plain text */
    }
  }
  return text;
}

function listingTime(row: Record<string, unknown>, stamp: string, textKey: string): number {
  const unix = Number(row[stamp]);
  if (Number.isFinite(unix) && unix > 1_000_000_000_000) return unix;
  if (Number.isFinite(unix) && unix > 1_000_000_000) return unix * 1000;
  const text = String(row[textKey] ?? "").trim();
  if (!text) return Number.NaN;
  const parsed = Date.parse(text.includes("T") ? text : text.replace(" ", "T"));
  return Number.isFinite(parsed) ? parsed : Number.NaN;
}

function listingRows(data: unknown): Array<Record<string, unknown>> {
  if (Array.isArray(data)) return data.filter((row) => row && typeof row === "object") as Array<Record<string, unknown>>;
  if (!data || typeof data !== "object") return [];
  const record = data as Record<string, unknown>;
  return asList<Record<string, unknown>>(record.epg_listings ?? record);
}

async function loadShortEpg(
  xmltvUrl: string,
  channels: Channel[],
  now: number,
  onBatch?: (channels: Channel[]) => void,
): Promise<Channel[]> {
  let page: URL;
  try {
    page = new URL(xmltvUrl);
  } catch {
    return channels;
  }
  const username = page.searchParams.get("username") ?? "";
  const password = page.searchParams.get("password") ?? "";
  if (!username || !password) return channels;
  const base = `${page.protocol}//${page.host}`;
  const pending = channels.filter((channel) => channel.guide !== "epg" && channel.id.startsWith("xt-")).slice(0, 400);
  const programs = new Map<string, Program[]>();
  let cursor = 0;
  let published = 0;
  function publish() {
    if (!onBatch || programs.size === published) return;
    published = programs.size;
    onBatch(
      channels.map((channel) => {
        const list = programs.get(channel.id);
        return list ? { ...channel, programs: list, guide: "epg" as const } : channel;
      }),
    );
  }
  async function worker() {
    while (cursor < pending.length) {
      const channel = pending[cursor];
      cursor += 1;
      const streamId = channel.id.replace(/^xt-/, "");
      const endpoint = `${base}/player_api.php?username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}&action=get_short_epg&stream_id=${encodeURIComponent(streamId)}&limit=12`;
      try {
        const response = await fetch(`${previewAsset("/api/media")}?url=${encodeURIComponent(endpoint)}`);
        if (!response.ok) continue;
        const rows = listingRows(await response.json());
        const list: Program[] = [];
        for (const row of rows) {
          const start = listingTime(row, "start_timestamp", "start");
          const end = listingTime(row, "stop_timestamp", "end");
          if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start) continue;
          if (end < now - 2 * 60 * 60 * 1000 || start > now + 12 * 60 * 60 * 1000) continue;
          list.push({
            id: String(row.id ?? `${streamId}-${start}`),
            title: decodeField(row.title) || "Programme",
            start,
            end,
            description: decodeField(row.description),
          });
        }
        if (list.length) {
          programs.set(channel.id, list.sort((a, b) => a.start - b.start));
          if (programs.size % 12 === 0) publish();
        }
      } catch {
        /* this channel has no listing */
      }
    }
  }
  await Promise.all(Array.from({ length: 6 }, () => worker()));
  publish();
  if (programs.size === 0) return channels;
  return channels.map((channel) => {
    const list = programs.get(channel.id);
    return list ? { ...channel, programs: list, guide: "epg" } : channel;
  });
}

export async function loadEpg(
  url: string,
  channels: Channel[],
  now = Date.now(),
  onBatch?: (channels: Channel[]) => void,
): Promise<Channel[]> {
  const shortPromise = url.includes("xmltv.php") ? loadShortEpg(url, channels, now, onBatch) : Promise.resolve(channels);
  let fromXml = channels;
  try {
    const xml = await readPayload(url);
    if (xml.includes("<programme")) fromXml = applyXmltv(channels, xml, now);
  } catch {
    /* the full file failed; the short guide can still fill the rows */
  }
  const fromShort = await shortPromise;
  const shortById = new Map(fromShort.map((channel) => [channel.id, channel]));
  return fromXml.map((channel) => (channel.guide === "epg" ? channel : (shortById.get(channel.id) ?? channel)));
}

export function loadSavedSource(): Source {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { mode: "demo" };
    const parsed = JSON.parse(raw) as Source;
    if (parsed?.mode === "m3u" && parsed.url) return parsed;
    if (parsed?.mode === "xtream" && parsed.server && parsed.username) return parsed;
  } catch {
    /* ignore broken storage */
  }
  return { mode: "demo" };
}

export function saveSource(source: Source) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(source));
}

export function loadFavorites(): string[] {
  try {
    const raw = localStorage.getItem(`${STORAGE_KEY}-favs`);
    const parsed = raw ? (JSON.parse(raw) as unknown) : [];
    return Array.isArray(parsed) ? parsed.filter((item) => typeof item === "string") : [];
  } catch {
    return [];
  }
}

export function saveFavorites(ids: string[]) {
  localStorage.setItem(`${STORAGE_KEY}-favs`, JSON.stringify(ids));
}

export function formatClock(now: number): string {
  return new Intl.DateTimeFormat("en", {
    weekday: "short",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  }).format(now);
}

export function formatTime(stamp: number): string {
  return new Intl.DateTimeFormat("en", { hour: "numeric", minute: "2-digit" }).format(stamp);
}
